@echo off
chcp 65001 >nul
title 時空數學密室逃脫 - 國小四年級四則運算大冒險

cd /d "%~dp0"

:: 優先檢查是否有編譯好的獨立 EXE 執行檔
if exist "時空數學密室逃脫.exe" (
    start "" "時空數學密室逃脫.exe"
    exit /b
)

:: 檢測 Microsoft Edge 應用視窗模式 (Windows 10/11 預設內建)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%~dp0index.html" --window-size=1280,760
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="file:///%~dp0index.html" --window-size=1280,760
    exit /b
)

:: 檢測 Google Chrome 應用視窗模式
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%~dp0index.html" --window-size=1280,760
    exit /b
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="file:///%~dp0index.html" --window-size=1280,760
    exit /b
)

:: 若無上述路徑，直接以系統預設瀏覽器啟動
start "" "%~dp0index.html"
exit /b
