// escape_game.js - 3D First-Person 360-Degree Panoramic Escape Room World Engine
// Powered by Three.js & Procedural 3D Environment Builders

class EscapeGame {
    constructor() {
        this.container = document.getElementById('webgl-container');
        this.scene = null;
        this.camera = null;
        this.renderer = null;

        // Camera rotation control
        this.isUserInteracting = false;
        this.onPointerDownMouseX = 0;
        this.onPointerDownMouseY = 0;
        this.lon = 0;
        this.onPointerDownLon = 0;
        this.lat = 0;
        this.onPointerDownLat = 0;
        this.phi = 0;
        this.theta = 0;
        this.targetFov = 75;

        // Raycasting & Interaction
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        this.interactiveObjects = [];
        this.hoveredObject = null;

        // Game State
        this.currentRoom = 1; // 1, 2, or 3
        this.playerName = '數學小偵探';
        this.score = 0;
        this.certificatesEarned = 0;
        this.gameStartTime = null;
        this.timerInterval = null;
        this.elapsedSeconds = 0;
        this.inventory = [];
        this.currentQuestion = null;

        // Animated elements
        this.animatedMeshes = [];
        this.flickerLights = [];

        this.init();
    }

    init() {
        // 1. Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x0a0a0e);

        // 2. Camera (First Person at center)
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        this.camera.position.set(0, 0, 0);

        // 3. Renderer
        this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.container.appendChild(this.renderer.domElement);

        // 4. Event Listeners
        this.setupEventListeners();

        // 5. Build Room 1
        this.buildRoom(1);

        // 6. Start Render Loop
        this.animate();
    }

    setupEventListeners() {
        const dom = this.renderer.domElement;

        // Pointer controls
        dom.addEventListener('pointerdown', (e) => {
            this.isUserInteracting = true;
            this.onPointerDownMouseX = e.clientX;
            this.onPointerDownMouseY = e.clientY;
            this.onPointerDownLon = this.lon;
            this.onPointerDownLat = this.lat;
        });

        window.addEventListener('pointermove', (e) => {
            if (this.isUserInteracting) {
                this.lon = (this.onPointerDownMouseX - e.clientX) * 0.18 + this.onPointerDownLon;
                this.lat = (e.clientY - this.onPointerDownMouseY) * 0.18 + this.onPointerDownLat;
            }

            // Raycasting on hover
            const rect = dom.getBoundingClientRect();
            this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
            this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
            this.checkHover();
        });

        window.addEventListener('pointerup', () => {
            this.isUserInteracting = false;
        });

        // Click / Tap for interaction
        dom.addEventListener('click', (e) => {
            this.handleClick(e);
        });

        // Wheel Zoom (FOV)
        dom.addEventListener('wheel', (e) => {
            e.preventDefault();
            this.targetFov = Math.max(45, Math.min(85, this.camera.fov + e.deltaY * 0.05));
        }, { passive: false });

        // Window resize
        window.addEventListener('resize', () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
        });
    }

    // Clear current room
    clearRoom() {
        while (this.scene.children.length > 0) {
            const obj = this.scene.children[0];
            this.scene.remove(obj);
        }
        this.interactiveObjects = [];
        this.animatedMeshes = [];
        this.flickerLights = [];
    }

    // Build Room dispatcher
    buildRoom(roomNum) {
        if (roomNum === 1) this.buildRoom1();
        else if (roomNum === 2) this.buildRoom2();
        else if (roomNum === 3) this.buildRoom3();
    }

    // =========================================================================
    // ROOM 1: 歐式古典莊園書房 (Vintage Victorian Manor)
    // =========================================================================
    buildRoom1() {
        this.clearRoom();
        this.currentRoom = 1;
        this.updateRoomBadge();
        document.body.className = 'theme-room1';

        // 1. Ambient & Lighting
        const ambientLight = new THREE.AmbientLight(0xffeedd, 0.65);
        this.scene.add(ambientLight);

        // Fireplace warm hearth point light
        const fireLight = new THREE.PointLight(0xff6600, 2.2, 18);
        fireLight.position.set(-8.5, -1.8, -2.5);
        this.scene.add(fireLight);
        this.flickerLights.push({ light: fireLight, base: 2.2, color: 0xff7711 });

        // Ceiling chandelier warm light
        const chLight = new THREE.PointLight(0xffe2aa, 1.4, 25);
        chLight.position.set(0, 5.5, 0);
        this.scene.add(chLight);

        // 2. Room Walls & Box
        const textures = window.roomTextures;
        const woodFloor = textures.getVintageWoodFloor();
        const wallpaper = textures.getVictorianWallpaper();
        const ceilingTex = textures.getVintageCeiling();

        const boxGeo = new THREE.BoxGeometry(20, 14, 20);
        const materials = [
            new THREE.MeshLambertMaterial({ map: wallpaper, side: THREE.BackSide }), // Right (+X)
            new THREE.MeshLambertMaterial({ map: wallpaper, side: THREE.BackSide }), // Left (-X)
            new THREE.MeshLambertMaterial({ map: ceilingTex, side: THREE.BackSide }),// Top (+Y)
            new THREE.MeshLambertMaterial({ map: woodFloor, side: THREE.BackSide }), // Bottom (-Y)
            new THREE.MeshLambertMaterial({ map: wallpaper, side: THREE.BackSide }), // Front (+Z)
            new THREE.MeshLambertMaterial({ map: wallpaper, side: THREE.BackSide })  // Back (-Z)
        ];
        const roomBox = new THREE.Mesh(boxGeo, materials);
        this.scene.add(roomBox);

        // 3. Vault Door with Brass Lock on Front Wall (Z = -9.9)
        const doorGeo = new THREE.PlaneGeometry(5.2, 9.5);
        const doorMat = new THREE.MeshLambertMaterial({ map: textures.getVintageDoor() });
        const doorMesh = new THREE.Mesh(doorGeo, doorMat);
        doorMesh.position.set(0, -2.2, -9.85);
        doorMesh.userData = {
            type: 'door',
            name: '莊園神秘拱門密碼鎖',
            actionText: '調查密碼鎖進行初級四則運算解鎖！'
        };
        this.scene.add(doorMesh);
        this.interactiveObjects.push(doorMesh);

        // Glowing marker on door lock
        this.createFloatingMarker(0, -1.8, -9.7, 0x00ff88, '解鎖大門');

        // 4. Stone Fireplace on Left Wall (X = -9.9)
        const fpGroup = new THREE.Group();
        const fpMantelGeo = new THREE.BoxGeometry(2, 6, 8);
        const fpMat = new THREE.MeshLambertMaterial({ map: textures.getFireplaceBrick() });
        const fpMesh = new THREE.Mesh(fpMantelGeo, fpMat);
        fpMesh.position.set(-9.0, -3.8, -2.5);
        fpGroup.add(fpMesh);

        // Fireplace hearth cavity (Dark cutout)
        const hearthGeo = new THREE.BoxGeometry(1.5, 3.5, 4.5);
        const hearthMat = new THREE.MeshBasicMaterial({ color: 0x110804 });
        const hearthMesh = new THREE.Mesh(hearthGeo, hearthMat);
        hearthMesh.position.set(-8.7, -4.5, -2.5);
        fpGroup.add(hearthMesh);

        // Burning glowing logs inside
        const logGeo = new THREE.CylinderGeometry(0.2, 0.2, 3, 8);
        const logMat = new THREE.MeshLambertMaterial({ color: 0x3d1c06 });
        const logMesh = new THREE.Mesh(logGeo, logMat);
        logMesh.rotation.z = Math.PI / 2;
        logMesh.position.set(-8.5, -5.2, -2.5);
        fpGroup.add(logMesh);

        // Fire flame particle mesh
        const flameGeo = new THREE.ConeGeometry(0.8, 1.8, 8);
        const flameMat = new THREE.MeshBasicMaterial({ color: 0xff6600, wireframe: true });
        const flameMesh = new THREE.Mesh(flameGeo, flameMat);
        flameMesh.position.set(-8.4, -4.6, -2.5);
        fpGroup.add(flameMesh);
        this.animatedMeshes.push({ mesh: flameMesh, type: 'flame' });

        this.scene.add(fpGroup);

        // 5. Classical Oil Painting above fireplace on Left Wall
        const paintGeo = new THREE.PlaneGeometry(4.5, 5.8);
        const paintMat = new THREE.MeshLambertMaterial({ map: textures.getOilPaintingTexture() });
        const paintMesh = new THREE.Mesh(paintGeo, paintMat);
        paintMesh.rotation.y = Math.PI / 2;
        paintMesh.position.set(-9.85, 2.5, -2.5);
        this.scene.add(paintMesh);

        // 6. Antique Study Desk on Right Side (X = 6, Z = -4)
        const deskGroup = new THREE.Group();
        const topGeo = new THREE.BoxGeometry(4.5, 0.4, 7.5);
        const woodMat = new THREE.MeshLambertMaterial({ color: 0x42220f });
        const topMesh = new THREE.Mesh(topGeo, woodMat);
        topMesh.position.set(6.5, -3.5, -4);
        deskGroup.add(topMesh);

        // Desk legs
        const legGeo = new THREE.BoxGeometry(0.4, 3.5, 0.4);
        const legPositions = [
            [4.5, -5.25, -7.5],
            [8.5, -5.25, -7.5],
            [4.5, -5.25, -0.5],
            [8.5, -5.25, -0.5]
        ];
        legPositions.forEach(pos => {
            const leg = new THREE.Mesh(legGeo, woodMat);
            leg.position.set(pos[0], pos[1], pos[2]);
            deskGroup.add(leg);
        });
        this.scene.add(deskGroup);

        // 7. Interactive Items in Room 1:
        // Item 1: 【智慧透視放大鏡】 (On the Desk: X = 5.8, Y = -3.2, Z = -4.2)
        const magGroup = this.createMagnifierMesh();
        magGroup.position.set(5.8, -3.2, -4.2);
        magGroup.userData = {
            type: 'item',
            itemId: 'magnifier',
            name: '智慧透視放大鏡',
            category: 'aid',
            desc: '自動透視標註四則運算中「該先算的步驟」！',
            icon: '🔍',
            actionText: '拾取道具：智慧透視放大鏡',
            marker: this.createFloatingMarker(5.8, -2.5, -4.2, 0xffd700, '放大鏡')
        };
        this.scene.add(magGroup);
        this.interactiveObjects.push(magGroup);

        // Item 2: 【莊園黃金懷錶】 (On Fireplace Mantel: X = -8.5, Y = -0.6, Z = -1.2)
        const watchMesh = this.createPocketWatchMesh();
        watchMesh.position.set(-8.5, -0.6, -1.2);
        watchMesh.userData = {
            type: 'item',
            itemId: 'gold_watch',
            name: '莊園黃金懷錶',
            category: 'score',
            points: 300,
            desc: '珍貴的古董金錶，立即獲得 +300 積分！',
            icon: '⏱️',
            actionText: '拾取道具：莊園黃金懷錶 (+300分)',
            marker: this.createFloatingMarker(-8.5, 0.1, -1.2, 0xffbb00, '+300分懷錶')
        };
        this.scene.add(watchMesh);
        this.interactiveObjects.push(watchMesh);

        // Item 3: 【神秘算術羊皮紙】 (Near broken floor: X = 1.2, Y = -6.8, Z = -3.5)
        const parchMesh = this.createParchmentMesh();
        parchMesh.position.set(1.2, -6.85, -3.5);
        parchMesh.rotation.x = -Math.PI / 2;
        parchMesh.userData = {
            type: 'item',
            itemId: 'parchment',
            name: '神秘算術羊皮紙',
            category: 'aid',
            desc: '古老學者的演算稿，使用後消除 1 個錯誤選項！',
            icon: '📜',
            actionText: '拾取道具：神秘算術羊皮紙',
            marker: this.createFloatingMarker(1.2, -6.0, -3.5, 0x00f0ff, '羊皮紙')
        };
        this.scene.add(parchMesh);
        this.interactiveObjects.push(parchMesh);

        // 8. Chandelier in Center Ceiling
        const chGroup = new THREE.Group();
        const chainGeo = new THREE.CylinderGeometry(0.05, 0.05, 2.5);
        const goldMat = new THREE.MeshLambertMaterial({ color: 0xaa8c2c });
        const chain = new THREE.Mesh(chainGeo, goldMat);
        chain.position.set(0, 5.75, 0);
        chGroup.add(chain);

        const ringGeo = new THREE.TorusGeometry(1.6, 0.1, 8, 24);
        const ring = new THREE.Mesh(ringGeo, goldMat);
        ring.rotation.x = Math.PI / 2;
        ring.position.set(0, 4.5, 0);
        chGroup.add(ring);
        this.scene.add(chGroup);

        // Soundscape
        window.soundEngine.playAmbient(0);
    }

    // =========================================================================
    // ROOM 2: 未來科幻量子實驗室 (Cyberpunk Quantum Lab)
    // =========================================================================
    buildRoom2() {
        this.clearRoom();
        this.currentRoom = 2;
        this.updateRoomBadge();
        document.body.className = 'theme-room2';

        // 1. Cyber Ambient & Neon Lights
        const ambientLight = new THREE.AmbientLight(0x112244, 0.8);
        this.scene.add(ambientLight);

        // Central Quantum Core Cyan Glow Light
        const coreLight = new THREE.PointLight(0x00ffff, 2.8, 22);
        coreLight.position.set(-6, 0, 5);
        this.scene.add(coreLight);
        this.flickerLights.push({ light: coreLight, base: 2.8, color: 0x00ffff });

        // Magenta Accent Light
        const magLight = new THREE.PointLight(0xff0088, 2.0, 18);
        magLight.position.set(6, 2, -4);
        this.scene.add(magLight);

        // 2. Room Box with Cyber Textures
        const textures = window.roomTextures;
        const cyberFloor = textures.getCyberFloor();
        const cyberWall = textures.getCyberWall();

        const boxGeo = new THREE.BoxGeometry(20, 14, 20);
        const materials = [
            new THREE.MeshLambertMaterial({ map: cyberWall, side: THREE.BackSide }), // Right
            new THREE.MeshLambertMaterial({ map: cyberWall, side: THREE.BackSide }), // Left
            new THREE.MeshLambertMaterial({ color: 0x070b12, side: THREE.BackSide }),// Ceiling
            new THREE.MeshLambertMaterial({ map: cyberFloor, side: THREE.BackSide }),// Floor
            new THREE.MeshLambertMaterial({ map: cyberWall, side: THREE.BackSide }), // Front
            new THREE.MeshLambertMaterial({ map: cyberWall, side: THREE.BackSide })  // Back
        ];
        const roomBox = new THREE.Mesh(boxGeo, materials);
        this.scene.add(roomBox);

        // 3. Cyber Blast Door with Digital Touch Lock at Back Wall (Z = -9.9)
        const doorGeo = new THREE.PlaneGeometry(5.4, 9.5);
        const doorMat = new THREE.MeshLambertMaterial({ map: textures.getCyberDoor() });
        const doorMesh = new THREE.Mesh(doorGeo, doorMat);
        doorMesh.position.set(0, -2.2, -9.85);
        doorMesh.userData = {
            type: 'door',
            name: '量子實驗室力場防護閘門',
            actionText: '啟動終端進行四則運算邏輯判斷解鎖！'
        };
        this.scene.add(doorMesh);
        this.interactiveObjects.push(doorMesh);
        this.createFloatingMarker(0, -1.8, -9.7, 0x00ffff, '科技閘門');

        // 4. Spinning Quantum Energy Core (at X = -6, Z = 5)
        const coreGroup = new THREE.Group();
        coreGroup.position.set(-6, -1.5, 5);

        // Core pedestal
        const pedGeo = new THREE.CylinderGeometry(1.6, 2.0, 3.8, 16);
        const pedMat = new THREE.MeshLambertMaterial({ color: 0x152238 });
        const pedMesh = new THREE.Mesh(pedGeo, pedMat);
        pedMesh.position.set(0, -1.9, 0);
        coreGroup.add(pedMesh);

        // Rotating outer ring 1
        const ring1Geo = new THREE.TorusGeometry(1.8, 0.1, 8, 32);
        const ring1Mat = new THREE.MeshBasicMaterial({ color: 0x00f0ff, wireframe: true });
        const ring1 = new THREE.Mesh(ring1Geo, ring1Mat);
        coreGroup.add(ring1);
        this.animatedMeshes.push({ mesh: ring1, type: 'rotateX', speed: 0.02 });

        // Rotating ring 2
        const ring2Geo = new THREE.TorusGeometry(1.4, 0.1, 8, 32);
        const ring2Mat = new THREE.MeshBasicMaterial({ color: 0xff0088, wireframe: true });
        const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
        coreGroup.add(ring2);
        this.animatedMeshes.push({ mesh: ring2, type: 'rotateY', speed: 0.03 });

        // Floating plasma sphere
        const orbGeo = new THREE.SphereGeometry(0.7, 16, 16);
        const orbMat = new THREE.MeshBasicMaterial({ color: 0x00ffff });
        const orb = new THREE.Mesh(orbGeo, orbMat);
        coreGroup.add(orb);
        this.animatedMeshes.push({ mesh: orb, type: 'pulse' });

        this.scene.add(coreGroup);

        // 5. Hologram Control Console on Right Wall (X = 6.5, Z = -3)
        const consoleGroup = new THREE.Group();
        consoleGroup.position.set(6.5, -3.5, -3);

        const tableGeo = new THREE.BoxGeometry(4.5, 0.3, 6);
        const tableMat = new THREE.MeshLambertMaterial({ color: 0x111c2e });
        const tableMesh = new THREE.Mesh(tableGeo, tableMat);
        consoleGroup.add(tableMesh);

        // Holographic floating screen
        const holoGeo = new THREE.PlaneGeometry(3.5, 2.2);
        const holoMat = new THREE.MeshBasicMaterial({
            color: 0x00f0ff,
            transparent: true,
            opacity: 0.75,
            side: THREE.DoubleSide
        });
        const holoScreen = new THREE.Mesh(holoGeo, holoMat);
        holoScreen.position.set(0, 1.6, 0);
        holoScreen.rotation.y = -Math.PI / 4;
        consoleGroup.add(holoScreen);
        this.scene.add(consoleGroup);

        // 6. Interactive Items in Room 2:
        // Item 1: 【量子分析儀】 (On Holographic Console: X = 6.2, Y = -3.1, Z = -3.2)
        const analyzerMesh = this.createQuantumAnalyzerMesh();
        analyzerMesh.position.set(6.2, -3.1, -3.2);
        analyzerMesh.userData = {
            type: 'item',
            itemId: 'analyzer',
            name: '量子邏輯分析儀',
            category: 'aid',
            desc: '自動透析算式中的邏輯盲點與運算陷阱！',
            icon: '📟',
            actionText: '拾取道具：量子邏輯分析儀',
            marker: this.createFloatingMarker(6.2, -2.4, -3.2, 0x00f0ff, '分析儀')
        };
        this.scene.add(analyzerMesh);
        this.interactiveObjects.push(analyzerMesh);

        // Item 2: 【超能核心電池】 (Next to Quantum Core: X = -5.8, Y = 0.8, Z = 5.2)
        const batteryMesh = this.createEnergyCoreMesh();
        batteryMesh.position.set(-5.8, 0.8, 5.2);
        batteryMesh.userData = {
            type: 'item',
            itemId: 'energy_core',
            name: '超能核心電池',
            category: 'score',
            points: 500,
            desc: '充滿量子高頻能量，立即獲得 +500 積分！',
            icon: '🔋',
            actionText: '拾取道具：超能核心電池 (+500分)',
            marker: this.createFloatingMarker(-5.8, 1.4, 5.2, 0xff00bb, '+500分晶石')
        };
        this.scene.add(batteryMesh);
        this.interactiveObjects.push(batteryMesh);

        // Item 3: 【時間凍結裝置】 (Near wall console: X = 2.5, Y = -6.8, Z = 6.5)
        const timeMesh = this.createTimeWarpMesh();
        timeMesh.position.set(2.5, -6.8, 6.5);
        timeMesh.userData = {
            type: 'item',
            itemId: 'timewarp',
            name: '時光凍結模組',
            category: 'aid',
            desc: '凍結時間流動，並立即刪除一個錯誤干擾選項！',
            icon: '⌛',
            actionText: '拾取道具：時光凍結模組',
            marker: this.createFloatingMarker(2.5, -6.0, 6.5, 0x00ff88, '時光模組')
        };
        this.scene.add(timeMesh);
        this.interactiveObjects.push(timeMesh);

        window.soundEngine.playAmbient(1);
    }

    // =========================================================================
    // ROOM 3: 奇幻遠古神廟遺蹟 (Mystic Ancient Temple)
    // =========================================================================
    buildRoom3() {
        this.clearRoom();
        this.currentRoom = 3;
        this.updateRoomBadge();
        document.body.className = 'theme-room3';

        // 1. Ancient Mystic Ambient & Torchlight
        const ambientLight = new THREE.AmbientLight(0x2d1f3b, 0.7);
        this.scene.add(ambientLight);

        // Mystic Violet/Purple Altar Crystal Light
        const crystalLight = new THREE.PointLight(0xc445ff, 2.5, 20);
        crystalLight.position.set(0, 1.5, 5);
        this.scene.add(crystalLight);
        this.flickerLights.push({ light: crystalLight, base: 2.5, color: 0xc445ff });

        // Wall Torches Warm Flickering Light
        const torchLight1 = new THREE.PointLight(0xff9900, 2.2, 16);
        torchLight1.position.set(-8.5, 1.8, -4);
        this.scene.add(torchLight1);
        this.flickerLights.push({ light: torchLight1, base: 2.2, color: 0xff8800 });

        const torchLight2 = new THREE.PointLight(0xff9900, 2.2, 16);
        torchLight2.position.set(8.5, 1.8, -4);
        this.scene.add(torchLight2);
        this.flickerLights.push({ light: torchLight2, base: 2.2, color: 0xff8800 });

        // 2. Room Box with Ancient Rune Stone Textures
        const textures = window.roomTextures;
        const stoneFloor = textures.getTempleStoneFloor();
        const templeWall = textures.getTempleWall();

        const boxGeo = new THREE.BoxGeometry(20, 14, 20);
        const materials = [
            new THREE.MeshLambertMaterial({ map: templeWall, side: THREE.BackSide }), // Right
            new THREE.MeshLambertMaterial({ map: templeWall, side: THREE.BackSide }), // Left
            new THREE.MeshLambertMaterial({ color: 0x171513, side: THREE.BackSide }), // Ceiling
            new THREE.MeshLambertMaterial({ map: stoneFloor, side: THREE.BackSide }), // Floor
            new THREE.MeshLambertMaterial({ map: templeWall, side: THREE.BackSide }), // Front
            new THREE.MeshLambertMaterial({ map: templeWall, side: THREE.BackSide })  // Back
        ];
        const roomBox = new THREE.Mesh(boxGeo, materials);
        this.scene.add(roomBox);

        // 3. Grand Sun Vault Door at Back Wall (Z = -9.9)
        const doorGeo = new THREE.PlaneGeometry(5.4, 9.5);
        const doorMat = new THREE.MeshLambertMaterial({ map: textures.getTempleDoor() });
        const doorMesh = new THREE.Mesh(doorGeo, doorMat);
        doorMesh.position.set(0, -2.2, -9.85);
        doorMesh.userData = {
            type: 'door',
            name: '遠古神廟星芒巨門',
            actionText: '破解神廟情境應用銘文，榮獲大師證照！'
        };
        this.scene.add(doorMesh);
        this.interactiveObjects.push(doorMesh);
        this.createFloatingMarker(0, -1.8, -9.7, 0xffd700, '神殿星門');

        // 4. Four Massive Carved Stone Pillars
        const pillarGeo = new THREE.CylinderGeometry(0.9, 1.1, 14, 16);
        const pillarMat = new THREE.MeshLambertMaterial({ color: 0x3d3a33 });
        const pillarPositions = [
            [-6, 0, -5],
            [6, 0, -5],
            [-6, 0, 5],
            [6, 0, 5]
        ];
        pillarPositions.forEach(pos => {
            const pillar = new THREE.Mesh(pillarGeo, pillarMat);
            pillar.position.set(pos[0], pos[1], pos[2]);
            this.scene.add(pillar);
        });

        // 5. Mystic Ether Altar in Center (Z = 4.5)
        const altarGroup = new THREE.Group();
        altarGroup.position.set(0, -4.5, 4.5);

        // Stepped stone dais
        const dais1 = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.6, 0.8, 8), pillarMat);
        const dais2 = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.6, 0.8, 8), pillarMat);
        dais2.position.y = 0.8;
        altarGroup.add(dais1);
        altarGroup.add(dais2);

        // Giant floating celestial crystal
        const crystalGeo = new THREE.OctahedronGeometry(1.2, 0);
        const crystalMat = new THREE.MeshBasicMaterial({
            color: 0xc445ff,
            wireframe: false,
            transparent: true,
            opacity: 0.9
        });
        const crystalMesh = new THREE.Mesh(crystalGeo, crystalMat);
        crystalMesh.position.set(0, 3.2, 0);
        altarGroup.add(crystalMesh);
        this.animatedMeshes.push({ mesh: crystalMesh, type: 'floatRotate' });

        this.scene.add(altarGroup);

        // 6. Interactive Items in Room 3:
        // Item 1: 【先知符文石】 (On Altar Steps: X = -1.2, Y = -3.2, Z = 4.2)
        const runeMesh = this.createRuneStoneMesh();
        runeMesh.position.set(-1.2, -3.2, 4.2);
        runeMesh.userData = {
            type: 'item',
            itemId: 'rune_stone',
            name: '先知符文石',
            category: 'aid',
            desc: '自動列出情境應用題的「標準算式列式架構」！',
            icon: '🔮',
            actionText: '拾取道具：先知符文石',
            marker: this.createFloatingMarker(-1.2, -2.5, 4.2, 0xc445ff, '先知符文')
        };
        this.scene.add(runeMesh);
        this.interactiveObjects.push(runeMesh);

        // Item 2: 【遠古豐收金幣】 (Behind Left Pillar: X = -6.5, Y = -6.8, Z = -4.2)
        const coinMesh = this.createAncientRelicMesh();
        coinMesh.position.set(-6.5, -6.8, -4.2);
        coinMesh.userData = {
            type: 'item',
            itemId: 'ancient_relic',
            name: '遠古豐收金幣',
            category: 'score',
            points: 700,
            desc: '遠古黃金秘寶，立即狂加 +700 積分！',
            icon: '🪙',
            actionText: '拾取道具：遠古豐收金幣 (+700分)',
            marker: this.createFloatingMarker(-6.5, -6.0, -4.2, 0xffd700, '+700分金幣')
        };
        this.scene.add(coinMesh);
        this.interactiveObjects.push(coinMesh);

        // Item 3: 【勝利號角】 (Behind Right Pillar: X = 6.2, Y = -4.5, Z = 5.2)
        const hornMesh = this.createHornMesh();
        hornMesh.position.set(6.2, -4.5, 5.2);
        hornMesh.userData = {
            type: 'item',
            itemId: 'victory_horn',
            name: '智慧勝利號角',
            category: 'aid',
            desc: '吹響號角，直接將本關積分加成 1.5 倍並剔除錯誤選項！',
            icon: '📯',
            actionText: '拾取道具：智慧勝利號角',
            marker: this.createFloatingMarker(6.2, -3.7, 5.2, 0xffaa00, '勝利號角')
        };
        this.scene.add(hornMesh);
        this.interactiveObjects.push(hornMesh);

        window.soundEngine.playAmbient(2);
    }

    // =========================================================================
    // 3D ITEM MESH BUILDERS
    // =========================================================================

    // Magnifier Mesh for Room 1
    createMagnifierMesh() {
        const group = new THREE.Group();
        const rimGeo = new THREE.TorusGeometry(0.35, 0.05, 8, 16);
        const rimMat = new THREE.MeshLambertMaterial({ color: 0xd4af37 });
        const rim = new THREE.Mesh(rimGeo, rimMat);
        group.add(rim);

        const glassGeo = new THREE.CircleGeometry(0.33, 16);
        const glassMat = new THREE.MeshBasicMaterial({ color: 0x99e6ff, transparent: true, opacity: 0.6 });
        const glass = new THREE.Mesh(glassGeo, glassMat);
        group.add(glass);

        const handleGeo = new THREE.CylinderGeometry(0.04, 0.05, 0.7);
        const handleMat = new THREE.MeshLambertMaterial({ color: 0x5a2d0c });
        const handle = new THREE.Mesh(handleGeo, handleMat);
        handle.position.set(0, -0.65, 0);
        group.add(handle);

        group.rotation.x = -Math.PI / 3;
        return group;
    }

    // Pocket Watch Mesh for Room 1
    createPocketWatchMesh() {
        const group = new THREE.Group();
        const bodyGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.12, 16);
        const goldMat = new THREE.MeshLambertMaterial({ color: 0xffd700 });
        const body = new THREE.Mesh(bodyGeo, goldMat);
        body.rotation.x = Math.PI / 2;
        group.add(body);

        const dialGeo = new THREE.CircleGeometry(0.3, 16);
        const dialMat = new THREE.MeshBasicMaterial({ color: 0xfffae6 });
        const dial = new THREE.Mesh(dialGeo, dialMat);
        dial.position.z = 0.07;
        group.add(dial);

        return group;
    }

    // Parchment Mesh for Room 1
    createParchmentMesh() {
        const geo = new THREE.PlaneGeometry(0.9, 0.6);
        const mat = new THREE.MeshBasicMaterial({ color: 0xf5deb3, side: THREE.DoubleSide });
        return new THREE.Mesh(geo, mat);
    }

    // Quantum Analyzer Mesh for Room 2
    createQuantumAnalyzerMesh() {
        const group = new THREE.Group();
        const padGeo = new THREE.BoxGeometry(0.6, 0.1, 0.9);
        const padMat = new THREE.MeshLambertMaterial({ color: 0x0a1a2e });
        const pad = new THREE.Mesh(padGeo, padMat);
        group.add(pad);

        const scrGeo = new THREE.PlaneGeometry(0.5, 0.7);
        const scrMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
        const scr = new THREE.Mesh(scrGeo, scrMat);
        scr.rotation.x = -Math.PI / 2;
        scr.position.y = 0.06;
        group.add(scr);

        return group;
    }

    // Energy Core Battery Mesh for Room 2
    createEnergyCoreMesh() {
        const group = new THREE.Group();
        const cylGeo = new THREE.CylinderGeometry(0.25, 0.25, 0.9, 12);
        const cylMat = new THREE.MeshBasicMaterial({ color: 0xff00aa });
        const cyl = new THREE.Mesh(cylGeo, cylMat);
        group.add(cyl);

        const capGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.15, 12);
        const capMat = new THREE.MeshLambertMaterial({ color: 0x223344 });
        const cap1 = new THREE.Mesh(capGeo, capMat);
        cap1.position.y = 0.45;
        const cap2 = new THREE.Mesh(capGeo, capMat);
        cap2.position.y = -0.45;
        group.add(cap1);
        group.add(cap2);

        return group;
    }

    // Time Warp Module Mesh for Room 2
    createTimeWarpMesh() {
        const group = new THREE.Group();
        const cubeGeo = new THREE.BoxGeometry(0.5, 0.5, 0.5);
        const cubeMat = new THREE.MeshBasicMaterial({ color: 0x00ff88, wireframe: true });
        const cube = new THREE.Mesh(cubeGeo, cubeMat);
        group.add(cube);
        this.animatedMeshes.push({ mesh: cube, type: 'rotateY', speed: 0.04 });
        return group;
    }

    // Rune Stone Mesh for Room 3
    createRuneStoneMesh() {
        const group = new THREE.Group();
        const geo = new THREE.DodecahedronGeometry(0.4, 0);
        const mat = new THREE.MeshBasicMaterial({ color: 0xc445ff });
        const mesh = new THREE.Mesh(geo, mat);
        group.add(mesh);
        this.animatedMeshes.push({ mesh: mesh, type: 'floatRotate' });
        return group;
    }

    // Ancient Relic Gold Coin for Room 3
    createAncientRelicMesh() {
        const group = new THREE.Group();
        const geo = new THREE.CylinderGeometry(0.45, 0.45, 0.08, 16);
        const mat = new THREE.MeshLambertMaterial({ color: 0xffd700 });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.rotation.x = Math.PI / 4;
        group.add(mesh);
        return group;
    }

    // Victory Horn Mesh for Room 3
    createHornMesh() {
        const group = new THREE.Group();
        const geo = new THREE.ConeGeometry(0.35, 1.2, 8);
        const mat = new THREE.MeshLambertMaterial({ color: 0xe6a119 });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.rotation.z = Math.PI / 3;
        group.add(mesh);
        return group;
    }

    // Helper: 3D Floating Glowing Marker over interactive items
    createFloatingMarker(x, y, z, colorHex, label) {
        const markerGeo = new THREE.SphereGeometry(0.18, 12, 12);
        const markerMat = new THREE.MeshBasicMaterial({
            color: colorHex,
            transparent: true,
            opacity: 0.85
        });
        const marker = new THREE.Mesh(markerGeo, markerMat);
        marker.position.set(x, y, z);
        this.scene.add(marker);
        this.animatedMeshes.push({ mesh: marker, type: 'bounce', baseY: y });
        return marker;
    }

    // =========================================================================
    // RAYCASTING & INTERACTION LOGIC
    // =========================================================================

    checkHover() {
        this.raycaster.setFromCamera(this.mouse, this.camera);
        const intersects = this.raycaster.intersectObjects(this.interactiveObjects, true);

        const tip = document.getElementById('interaction-tip');
        if (intersects.length > 0) {
            let target = intersects[0].object;
            while (target.parent && !target.userData.type && target.parent !== this.scene) {
                target = target.parent;
            }

            if (target && target.userData && target.userData.type) {
                this.hoveredObject = target;
                document.body.style.cursor = 'pointer';

                if (tip) {
                    tip.style.display = 'block';
                    tip.innerText = target.userData.actionText || target.userData.name;
                }
                return;
            }
        }

        this.hoveredObject = null;
        document.body.style.cursor = 'default';
        if (tip) tip.style.display = 'none';
    }

    handleClick(e) {
        if (!this.hoveredObject) return;

        const data = this.hoveredObject.userData;
        if (data.type === 'item') {
            this.pickupItem(this.hoveredObject);
        } else if (data.type === 'door') {
            this.openDoorPuzzle();
        }
    }

    // Pick up item
    pickupItem(meshObj) {
        const item = meshObj.userData;
        window.soundEngine.playPickup();

        // Remove from 3D scene
        this.scene.remove(meshObj);
        const idx = this.interactiveObjects.indexOf(meshObj);
        if (idx !== -1) this.interactiveObjects.splice(idx, 1);

        // Remove attached floating marker if exists
        if (meshObj.userData.marker) {
            this.scene.remove(meshObj.userData.marker);
            const mIdx = this.animatedMeshes.findIndex(a => a.mesh === meshObj.userData.marker);
            if (mIdx !== -1) this.animatedMeshes.splice(mIdx, 1);
        }

        // Handle Immediate Score Items
        if (item.category === 'score') {
            this.addScore(item.points);
            this.showToast(`✨ 拾取秘寶【${item.name}】！積分 +${item.points}！`, 'success');
        } else {
            // Add to Inventory
            this.inventory.push(item);
            this.updateInventoryUI();
            this.showToast(`🎒 獲得解題輔助道具【${item.name}】！可隨時點擊使用。`, 'info');
        }

        this.hoveredObject = null;
        const tip = document.getElementById('interaction-tip');
        if (tip) tip.style.display = 'none';
    }

    // Add score with animation
    addScore(pts) {
        this.score += pts;
        const scoreEl = document.getElementById('hud-score-val');
        if (scoreEl) {
            scoreEl.innerText = this.score;
            scoreEl.classList.remove('score-pop');
            void scoreEl.offsetWidth; // trigger reflow
            scoreEl.classList.add('score-pop');
        }
    }

    // Update bottom inventory UI
    updateInventoryUI() {
        const invBar = document.getElementById('inventory-items');
        if (!invBar) return;
        invBar.innerHTML = '';

        if (this.inventory.length === 0) {
            invBar.innerHTML = '<span class="empty-inv">（在密室中環顧 360° 尋找發光道具）</span>';
            return;
        }

        this.inventory.forEach((item, index) => {
            const btn = document.createElement('div');
            btn.className = 'item-card';
            btn.innerHTML = `<span class="item-icon">${item.icon}</span><span class="item-label">${item.name}</span>`;
            btn.title = item.desc;
            btn.onclick = () => this.useItem(index);
            invBar.appendChild(btn);
        });
    }

    // Use item from inventory
    useItem(index) {
        const item = this.inventory[index];
        if (!item) return;

        window.soundEngine.playUseItem();

        if (item.itemId === 'magnifier' || item.itemId === 'analyzer' || item.itemId === 'rune_stone') {
            // Hint revealing item
            const hintBox = document.getElementById('puzzle-hint-box');
            if (hintBox && this.currentQuestion) {
                hintBox.style.display = 'block';
                hintBox.innerHTML = `<strong>💡【${item.name}】發動解密：</strong><br>${this.currentQuestion.hint}`;
                this.showToast(`🔍【${item.name}】已為您透視關鍵運算解法！`, 'success');
            } else {
                this.showToast(`💡【${item.name}】請在解題視窗開啟時使用，效果最佳！`, 'info');
            }
        } else if (item.itemId === 'parchment' || item.itemId === 'timewarp' || item.itemId === 'victory_horn') {
            // Eliminate 1 wrong answer item
            let eliminated = false;
            const optButtons = document.querySelectorAll('.puzzle-opt-btn:not(.eliminated)');
            for (const btn of optButtons) {
                if (btn.dataset.correct !== 'true') {
                    btn.classList.add('eliminated');
                    btn.disabled = true;
                    btn.innerHTML += ' ❌ (已排除)';
                    eliminated = true;
                    break;
                }
            }
            if (eliminated) {
                this.showToast(`⚡【${item.name}】已成功替您排除 1 個錯誤干擾選項！`, 'success');
            } else {
                this.showToast(`✨【${item.name}】已生效！`, 'info');
            }

            if (item.itemId === 'victory_horn') {
                this.addScore(500);
            }
        }

        // Remove item from inventory
        this.inventory.splice(index, 1);
        this.updateInventoryUI();
        this.updatePuzzleItemsBar();
    }

    // Update in-modal items bar
    updatePuzzleItemsBar() {
        const bar = document.getElementById('puzzle-items-bar');
        if (!bar) return;
        bar.innerHTML = '';

        if (this.inventory.length === 0) {
            bar.innerHTML = '<span class="modal-inv-tip">🎒 背包目前無輔助道具（可在 360° 密室中尋找發光放大鏡、羊皮紙或分析儀）</span>';
            return;
        }

        const title = document.createElement('div');
        title.className = 'modal-inv-title';
        title.innerHTML = '<strong>🎒 可用解題輔助道具 (點擊直接發動)：</strong>';
        bar.appendChild(title);

        const group = document.createElement('div');
        group.className = 'modal-inv-group';

        this.inventory.forEach((item, idx) => {
            const btn = document.createElement('button');
            btn.className = 'modal-item-btn';
            btn.innerHTML = `<span>${item.icon}</span> <span>使用【${item.name}】</span>`;
            btn.title = item.desc;
            btn.onclick = () => {
                this.useItem(idx);
            };
            group.appendChild(btn);
        });

        bar.appendChild(group);
    }

    // Open Door Puzzle
    openDoorPuzzle() {
        window.soundEngine.playClick();
        // Fetch new dynamic question from mathEngine
        this.currentQuestion = window.mathEngine.getQuestionForRoom(this.currentRoom);
        this.renderPuzzleModal(this.currentQuestion);
    }

    // Render Math Puzzle UI Modal
    renderPuzzleModal(q) {
        const modal = document.getElementById('puzzle-modal');
        const titleEl = document.getElementById('puzzle-title');
        const badgeEl = document.getElementById('puzzle-badge');
        const bodyEl = document.getElementById('puzzle-question');
        const optsContainer = document.getElementById('puzzle-options');
        const hintBox = document.getElementById('puzzle-hint-box');

        titleEl.innerText = q.roomName;
        badgeEl.innerText = q.category;
        bodyEl.innerText = q.question;
        hintBox.style.display = 'none';
        hintBox.innerHTML = '';

        // Update in-modal items
        this.updatePuzzleItemsBar();

        optsContainer.innerHTML = '';
        q.options.forEach((opt, idx) => {
            const btn = document.createElement('button');
            btn.className = 'puzzle-opt-btn';
            btn.innerText = `${String.fromCharCode(65 + idx)}.  ${opt.text}`;
            btn.dataset.correct = opt.isCorrect ? 'true' : 'false';
            btn.onclick = () => this.handleAnswerSelect(btn, opt.isCorrect, q);
            optsContainer.appendChild(btn);
        });

        modal.classList.add('active');
    }

    // Handle Option Selection
    handleAnswerSelect(btn, isCorrect, q) {
        const allBtns = document.querySelectorAll('.puzzle-opt-btn');
        allBtns.forEach(b => b.disabled = true);

        if (isCorrect) {
            btn.classList.add('correct');
            window.soundEngine.playCorrect();

            // Calculate speed bonus
            const speedBonus = 200;
            const earnedPoints = q.points + speedBonus;
            this.addScore(earnedPoints);

            this.showToast(`🎉 恭喜回答正確！獲得基礎積分 +${q.points}，極速獎勵 +${speedBonus}！`, 'success');

            // Wait 1.2s then open door and award certificate
            setTimeout(() => {
                const modal = document.getElementById('puzzle-modal');
                modal.classList.remove('active');
                this.handleRoomClear();
            }, 1200);

        } else {
            btn.classList.add('wrong');
            window.soundEngine.playWrong();
            this.showToast(`⚠️ 答案不太正確喔！請仔細觀察四則運算規則～`, 'error');

            // Show step-by-step guidance after wrong answer
            const hintBox = document.getElementById('puzzle-hint-box');
            if (hintBox) {
                hintBox.style.display = 'block';
                hintBox.innerHTML = `<strong>📖 解題步驟詳解：</strong><br>` + q.steps.join('<br>') +
                    `<br><br><button class="retry-btn" onclick="window.escapeGame.retryPuzzle()">🔄 重新整理題目再試一次</button>`;
            }
        }
    }

    // Retry puzzle with fresh dynamic question
    retryPuzzle() {
        window.soundEngine.playClick();
        this.openDoorPuzzle();
    }

    // Handle Room Clear & Certificates
    handleRoomClear() {
        window.soundEngine.playDoorOpen();
        this.certificatesEarned = this.currentRoom;

        // Fanfare & Show Certificate Modal
        setTimeout(() => {
            window.soundEngine.playFanfare();
            this.showCertificateModal(this.currentRoom);
        }, 800);
    }

    // Show Certificate Modal with dynamic canvas rendering
    showCertificateModal(certLevel) {
        const modal = document.getElementById('cert-modal');
        const certImg = document.getElementById('cert-canvas-img');
        const dlBtn = document.getElementById('cert-download-btn');
        const nextBtn = document.getElementById('cert-next-btn');

        const mins = Math.floor(this.elapsedSeconds / 60);
        const secs = this.elapsedSeconds % 60;
        const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

        // Generate dynamic canvas
        const canvas = window.leaderboardManager.generateCertificate(
            certLevel,
            this.playerName,
            this.score,
            timeStr
        );

        certImg.src = canvas.toDataURL('image/png');

        // Setup download button
        dlBtn.onclick = () => {
            const link = document.createElement('a');
            link.download = `${this.playerName}_四則運算第${certLevel}關證照.png`;
            link.href = certImg.src;
            link.click();
            window.soundEngine.playClick();
        };

        if (certLevel < 3) {
            nextBtn.innerText = `進入第 ${certLevel + 1} 密室 ➔`;
            nextBtn.onclick = () => {
                modal.classList.remove('active');
                window.soundEngine.playClick();
                if (certLevel === 1) {
                    this.buildRoom2();
                } else if (certLevel === 2) {
                    this.buildRoom3();
                }
                this.updateRoomBadge();
            };
        } else {
            // Final Room Cleared!
            nextBtn.innerText = '🏆 查看全體英雄積分排行榜';
            nextBtn.onclick = () => {
                modal.classList.remove('active');
                this.showFinalVictoryLeaderboard();
            };
        }

        modal.classList.add('active');
    }

    // Final Victory & Leaderboard
    showFinalVictoryLeaderboard() {
        clearInterval(this.timerInterval);

        // Record to leaderboard
        const records = window.leaderboardManager.addRecord(
            this.playerName,
            this.score,
            this.certificatesEarned,
            this.elapsedSeconds
        );

        this.renderLeaderboardModal(records);
    }

    renderLeaderboardModal(records) {
        const modal = document.getElementById('leaderboard-modal');
        const listEl = document.getElementById('leaderboard-list');

        listEl.innerHTML = '';
        records.forEach((rec, idx) => {
            const tr = document.createElement('tr');
            if (rec.isCurrent) tr.className = 'current-player-row';

            let rankBadge = `${idx + 1}`;
            if (idx === 0) rankBadge = '🥇 第 1 名';
            else if (idx === 1) rankBadge = '🥈 第 2 名';
            else if (idx === 2) rankBadge = '🥉 第 3 名';

            let certText = '';
            if (rec.certs === 1) certText = '🥉 初級證照';
            else if (rec.certs === 2) certText = '🥈 進階證照';
            else if (rec.certs >= 3) certText = '👑 大師證照';

            tr.innerHTML = `
                <td><strong>${rankBadge}</strong></td>
                <td><strong>${rec.name}</strong> ${rec.isCurrent ? '⭐ (你)' : ''}</td>
                <td class="table-score">${rec.score} 分</td>
                <td><span class="cert-pill">${certText}</span></td>
                <td>${rec.timeStr}</td>
                <td>${rec.date}</td>
            `;
            listEl.appendChild(tr);
        });

        modal.classList.add('active');
    }

    // Update Room Badge on HUD
    updateRoomBadge() {
        const badge = document.getElementById('hud-room-badge');
        if (badge) {
            badge.innerText = `當前：第 ${this.currentRoom} 密室 / 3`;
        }
    }

    // Start Timer
    startTimer() {
        this.elapsedSeconds = 0;
        if (this.timerInterval) clearInterval(this.timerInterval);
        this.timerInterval = setInterval(() => {
            this.elapsedSeconds++;
            const mins = Math.floor(this.elapsedSeconds / 60);
            const secs = this.elapsedSeconds % 60;
            const el = document.getElementById('hud-time-val');
            if (el) {
                el.innerText = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
            }
        }, 1000);
    }

    // Floating Toast Notification
    showToast(msg, type = 'info') {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = `game-toast toast-${type}`;
        toast.innerText = msg;
        container.appendChild(toast);

        setTimeout(() => {
            toast.classList.add('fade-out');
            setTimeout(() => toast.remove(), 400);
        }, 3200);
    }

    // =========================================================================
    // MAIN RENDER & ANIMATION LOOP
    // =========================================================================
    animate() {
        requestAnimationFrame(() => this.animate());

        // 1. Camera Rotation Lerp (Damping for smooth feel)
        this.lat = Math.max(-85, Math.min(85, this.lat));
        this.phi = THREE.MathUtils.degToRad(90 - this.lat);
        this.theta = THREE.MathUtils.degToRad(this.lon);

        const targetX = 500 * Math.sin(this.phi) * Math.cos(this.theta);
        const targetY = 500 * Math.cos(this.phi);
        const targetZ = 500 * Math.sin(this.phi) * Math.sin(this.theta);

        this.camera.lookAt(targetX, targetY, targetZ);

        // Smooth FOV zoom
        if (Math.abs(this.camera.fov - this.targetFov) > 0.1) {
            this.camera.fov += (this.targetFov - this.camera.fov) * 0.1;
            this.camera.updateProjectionMatrix();
        }

        // 2. Animated Meshes (Rings, Orbs, Flames, Bouncing Markers)
        const time = Date.now() * 0.003;
        this.animatedMeshes.forEach(item => {
            if (item.type === 'rotateX') {
                item.mesh.rotation.x += item.speed;
            } else if (item.type === 'rotateY') {
                item.mesh.rotation.y += item.speed;
            } else if (item.type === 'pulse') {
                const s = 1.0 + Math.sin(time * 3) * 0.15;
                item.mesh.scale.set(s, s, s);
            } else if (item.type === 'floatRotate') {
                item.mesh.rotation.y += 0.02;
                item.mesh.rotation.x = Math.sin(time) * 0.15;
                item.mesh.position.y += Math.sin(time * 2) * 0.003;
            } else if (item.type === 'bounce') {
                item.mesh.position.y = item.baseY + Math.sin(time * 4) * 0.15;
            } else if (item.type === 'flame') {
                item.mesh.scale.y = 1.0 + Math.sin(time * 8) * 0.25;
                item.mesh.scale.x = 1.0 + Math.cos(time * 8) * 0.15;
            }
        });

        // 3. Flickering Lights (Fireplace, Torches, Quantum Pulse)
        this.flickerLights.forEach(f => {
            f.light.intensity = f.base + (Math.random() - 0.5) * 0.4;
        });

        this.renderer.render(this.scene, this.camera);
    }
}

window.EscapeGame = EscapeGame;
