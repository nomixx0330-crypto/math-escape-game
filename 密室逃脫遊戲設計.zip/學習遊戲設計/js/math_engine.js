// math_engine.js - Grade 4 Elementary Math 4-Operations Dynamic Generator
// Unlimited dynamic generation with procedural distractors & step-by-step guidance

class MathEngine {
    constructor() {}

    // Random integer between min and max (inclusive)
    randInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // Pick random item from array
    choice(arr) {
        return arr[Math.floor(Math.random() * arr.length)];
    }

    // Shuffle array
    shuffle(arr) {
        const a = [...arr];
        for (let i = a.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [a[i], a[j]] = [a[j], a[i]];
        }
        return a;
    }

    // Generate unique choices including correct answer
    generateOptions(correctVal, distractors = []) {
        const set = new Set();
        set.add(correctVal);

        // Add valid distractors
        for (const d of distractors) {
            if (d !== correctVal && d > 0 && Number.isInteger(d)) {
                set.add(d);
            }
            if (set.size >= 4) break;
        }

        // Fill remaining with reasonable offsets
        let offset = 1;
        while (set.size < 4) {
            const cand1 = correctVal + offset * (Math.random() > 0.5 ? 1 : -1) * (Math.random() > 0.5 ? 5 : 10);
            const cand2 = correctVal + offset * (Math.random() > 0.5 ? 2 : -2);
            if (cand1 > 0 && !set.has(cand1)) set.add(cand1);
            if (cand2 > 0 && !set.has(cand2) && set.size < 4) set.add(cand2);
            offset++;
        }

        const options = Array.from(set).slice(0, 4);
        return this.shuffle(options);
    }

    // -------------------------------------------------------------
    // ROOM 1: 基本運算題 (Basic Calculation: Order of operations, parentheses)
    // -------------------------------------------------------------
    generateRoom1Question() {
        const types = ['add_mul', 'sub_mul', 'add_div', 'sub_div', 'paren_mul', 'paren_div', 'two_step_mixed'];
        const type = this.choice(types);

        let questionText = '';
        let formula = '';
        let answer = 0;
        let distractors = [];
        let hint = '';
        let steps = [];

        if (type === 'add_mul') {
            // A + B * C
            const b = this.randInt(4, 15);
            const c = this.randInt(3, 9);
            const a = this.randInt(15, 60);
            formula = `${a} + ${b} × ${c}`;
            answer = a + b * c;
            distractors = [
                (a + b) * c, // Mistake: add first
                a + b + c,
                answer + 10,
                answer - b
            ];
            hint = `四則運算口訣：「先乘除、後加減」！請先算乘法 ${b} × ${c}。`;
            steps = [
                `步驟 1：先算乘法部分 ${b} × ${c} = ${b * c}`,
                `步驟 2：再算加法部分 ${a} + ${b * c} = ${answer}`
            ];
        } else if (type === 'sub_mul') {
            // A - B * C
            const b = this.randInt(3, 12);
            const c = this.randInt(3, 8);
            const a = b * c + this.randInt(15, 50);
            formula = `${a} - ${b} × ${c}`;
            answer = a - b * c;
            distractors = [
                (a - b) * c, // Mistake: subtract first
                a - b - c,
                answer + 10,
                Math.max(1, answer - 10)
            ];
            hint = `四則運算規則：「先乘除、後加減」！請先算出 ${b} × ${c} 的積。`;
            steps = [
                `步驟 1：先算乘法 ${b} × ${c} = ${b * c}`,
                `步驟 2：再算減法 ${a} - ${b * c} = ${answer}`
            ];
        } else if (type === 'add_div') {
            // A + B / C
            const c = this.randInt(3, 9);
            const quotient = this.randInt(4, 15);
            const b = c * quotient;
            const a = this.randInt(20, 80);
            formula = `${a} + ${b} ÷ ${c}`;
            answer = a + quotient;
            distractors = [
                Math.floor((a + b) / c), // Mistake: add first
                a + b * c,
                answer + c,
                answer - 5
            ];
            hint = `四則運算規則：遇到加法和除法，要「先除、後加」！先算 ${b} ÷ ${c}。`;
            steps = [
                `步驟 1：先算除法 ${b} ÷ ${c} = ${quotient}`,
                `步驟 2：再算加法 ${a} + ${quotient} = ${answer}`
            ];
        } else if (type === 'sub_div') {
            // A - B / C
            const c = this.randInt(3, 8);
            const quotient = this.randInt(3, 12);
            const b = c * quotient;
            const a = quotient + this.randInt(20, 70);
            formula = `${a} - ${b} ÷ ${c}`;
            answer = a - quotient;
            distractors = [
                Math.floor((a - b) / c),
                a - quotient * 2,
                answer + 10,
                answer - c
            ];
            hint = `請牢記：除法優先於減法！先計算 ${b} ÷ ${c}。`;
            steps = [
                `步驟 1：先算除法 ${b} ÷ ${c} = ${quotient}`,
                `步驟 2：再算減法 ${a} - ${quotient} = ${answer}`
            ];
        } else if (type === 'paren_mul') {
            // (A + B) * C or (A - B) * C
            const isAdd = Math.random() > 0.5;
            const c = this.randInt(3, 8);
            if (isAdd) {
                const a = this.randInt(12, 45);
                const b = this.randInt(8, 35);
                formula = `(${a} + ${b}) × ${c}`;
                answer = (a + b) * c;
                distractors = [
                    a + b * c, // Mistake: ignored parentheses
                    a * c + b,
                    answer + 20,
                    answer - 10
                ];
                hint = `有括號的算式，一定要「先算括號裡面的數字」！`;
                steps = [
                    `步驟 1：先算括號內 ${a} + ${b} = ${a + b}`,
                    `步驟 2：再乘上外面的數 ${a + b} × ${c} = ${answer}`
                ];
            } else {
                const b = this.randInt(10, 30);
                const a = b + this.randInt(10, 35);
                formula = `(${a} - ${b}) × ${c}`;
                answer = (a - b) * c;
                distractors = [
                    a - b * c,
                    (a - b) + c,
                    answer + 15,
                    Math.max(5, answer - 15)
                ];
                hint = `算式中有括號，請「優先計算括號內的減法」！`;
                steps = [
                    `步驟 1：先算括號內 ${a} - ${b} = ${a - b}`,
                    `步驟 2：再乘上 ${c}：${a - b} × ${c} = ${answer}`
                ];
            }
        } else if (type === 'paren_div') {
            // (A - B) / C
            const c = this.randInt(3, 8);
            const quotient = this.randInt(4, 18);
            const diff = c * quotient;
            const b = this.randInt(15, 60);
            const a = b + diff;
            formula = `(${a} - ${b}) ÷ ${c}`;
            answer = quotient;
            distractors = [
                Math.floor(a - b / c), // Mistake: no paren
                quotient + c,
                quotient * 2,
                Math.max(1, quotient - 3)
            ];
            hint = `括號是最高優先級！先算括號內的差，再進行除法。`;
            steps = [
                `步驟 1：先算括號內 ${a} - ${b} = ${diff}`,
                `步驟 2：再算除法 ${diff} ÷ ${c} = ${answer}`
            ];
        } else {
            // two_step_mixed: A × B - C ÷ D or A + B × C - D
            const a = this.randInt(10, 16);
            const b = this.randInt(3, 6);
            const d = this.randInt(2, 5);
            const quot = this.randInt(2, 6);
            const c = d * quot;
            formula = `${a} × ${b} - ${c} ÷ ${d}`;
            answer = a * b - quot;
            distractors = [
                (a * b - c) / d,
                a * (b - c / d),
                answer + 10,
                answer - 5
            ];
            hint = `同時有乘除與減法時，同時先算出「乘法」與「除法」，最後再做減法！`;
            steps = [
                `步驟 1：先算乘法 ${a} × ${b} = ${a * b}`,
                `步驟 2：先算除法 ${c} ÷ ${d} = ${quot}`,
                `步驟 3：最後做減法 ${a * b} - ${quot} = ${answer}`
            ];
        }

        questionText = `請計算下列算式的正確結果：\n【 ${formula} 】`;
        const options = this.generateOptions(answer, distractors);

        return {
            room: 1,
            roomName: '第一密室：歐式古典莊園書房',
            category: '基本運算題',
            question: questionText,
            formula: formula,
            options: options.map(opt => ({
                text: `${opt}`,
                value: opt,
                isCorrect: opt === answer
            })),
            correctAnswer: answer,
            hint: hint,
            steps: steps,
            points: 1000
        };
    }

    // -------------------------------------------------------------
    // ROOM 2: 判斷題 (Judgment / True-False / Equivalence / Error Spotting)
    // -------------------------------------------------------------
    generateRoom2Question() {
        const types = ['calc_error', 'distributive_property', 'parentheses_compare', 'who_is_right'];
        const type = this.choice(types);

        if (type === 'calc_error') {
            // E.g. Check if "40 - 20 ÷ 4 = 5" is correct
            const a = this.randInt(30, 80);
            const div = this.randInt(2, 6);
            const quot = this.randInt(3, 8);
            const b = div * quot;
            const correctResult = a - quot;
            const wrongResult = Math.floor((a - b) / div); // calculate left to right directly

            const isShownCorrect = Math.random() > 0.5;
            const shownResult = isShownCorrect ? correctResult : wrongResult;
            const formula = `${a} - ${b} ÷ ${div} = ${shownResult}`;

            const qText = `【運算驗證】量子終端顯示了一道計算式：\n「 ${formula} 」\n請問這個算式的計算結果是否正確？`;

            let correctOpt = '';
            let options = [];
            let hint = `檢驗四則運算時，必須嚴格檢查是否遵循「先乘除後加減」原則！`;
            let steps = [];

            if (isShownCorrect) {
                correctOpt = `正確！因為先算 ${b} ÷ ${div} = ${quot}，再算 ${a} - ${quot} = ${correctResult}`;
                options = [
                    { text: correctOpt, isCorrect: true },
                    { text: `錯誤，應該先算減法 ${a} - ${b}，答案應為 ${wrongResult}`, isCorrect: false },
                    { text: `錯誤，正確答案應該是 ${correctResult + 10}`, isCorrect: false },
                    { text: `錯誤，加減乘除由左至右計算才對`, isCorrect: false }
                ];
                steps = [
                    `正確步驟：先乘除後加減。`,
                    `先算除法：${b} ÷ ${div} = ${quot}`,
                    `再算減法：${a} - ${quot} = ${correctResult}`,
                    `顯示結果與正解吻合，因此該算式正確！`
                ];
            } else {
                correctOpt = `錯誤！應先算除法 ${b} ÷ ${div} = ${quot}，正確答案應是 ${correctResult}`;
                options = [
                    { text: correctOpt, isCorrect: true },
                    { text: `正確！因為由左至右先減再除完全正確`, isCorrect: false },
                    { text: `錯誤，但正確答案應該是 ${wrongResult + 5}`, isCorrect: false },
                    { text: `正確，四則運算不需要分先後順序`, isCorrect: false }
                ];
                steps = [
                    `陷阱分析：題目直接由左往右算成了 (${a} - ${b}) ÷ ${div} = ${wrongResult}，這是常見錯誤！`,
                    `正確運算：先算除法 ${b} ÷ ${div} = ${quot}，再算 ${a} - ${quot} = ${correctResult}。`
                ];
            }

            return {
                room: 2,
                roomName: '第二密室：未來科幻量子實驗室',
                category: '判斷題 (運算真偽)',
                question: qText,
                formula: formula,
                options: this.shuffle(options),
                correctAnswer: correctOpt,
                hint: hint,
                steps: steps,
                points: 2000
            };
        } else if (type === 'distributive_property') {
            // E.g. (A + B) * C == A * C + B * C ?
            const a = this.randInt(12, 35);
            const b = this.randInt(8, 25);
            const c = this.randInt(4, 9);

            const qText = `【性質判斷】下列關於算式比較的敘述，哪一個是「正確」的？\n甲算式：(${a} + ${b}) × ${c}\n乙算式：${a} × ${c} + ${b} × ${c}`;

            const correctOpt = `甲算式與乙算式的計算結果「完全相同」（乘法分配律）`;
            const options = [
                { text: correctOpt, isCorrect: true },
                { text: `甲算式的結果比乙算式「大」，因為甲先算加法`, isCorrect: false },
                { text: `乙算式的結果比甲算式「大」，因為乙有兩個乘號`, isCorrect: false },
                { text: `兩個算式無法比較，因為括號不可拆開`, isCorrect: false }
            ];

            return {
                room: 2,
                roomName: '第二密室：未來科幻量子實驗室',
                category: '判斷題 (分配律判定)',
                question: qText,
                formula: `(${a} + ${b}) × ${c} vs ${a} × ${c} + ${b} × ${c}`,
                options: this.shuffle(options),
                correctAnswer: correctOpt,
                hint: `想一想四年級學過的「乘法對加法的分配律」：兩個數的和乘上一個數，等於分別乘上後再相加！`,
                steps: [
                    `甲算式：(${a} + ${b}) × ${c} = ${a + b} × ${c} = ${(a + b) * c}`,
                    `乙算式：${a} × ${c} + ${b} × ${c} = ${a * c} + ${b * c} = ${(a + b) * c}`,
                    `兩者完全相等，這就是重要的乘法分配律！`
                ],
                points: 2000
            };
        } else if (type === 'parentheses_compare') {
            // 100 - (A + B) vs 100 - A + B
            const a = this.randInt(20, 45);
            const b = this.randInt(10, 25);
            const total = 100;
            const res1 = total - (a + b);
            const res2 = total - a + b;

            const qText = `【去括號陷阱】小研說：「100 - (${a} + ${b})」和「100 - ${a} + ${b}」這兩個算式意思一樣，算出來也相同。\n請問小研的說法正確嗎？為什麼？`;

            const correctOpt = `不正確！前者等於 ${res1}，後者等於 ${res2}，去括號後加號必須變成減號。`;
            const options = [
                { text: correctOpt, isCorrect: true },
                { text: `正確！括號只是標記，去掉後完全不影響答案`, isCorrect: false },
                { text: `正確！兩者算出來都等於 ${res1}`, isCorrect: false },
                { text: `不正確！前者等於 ${res2}，後者等於 ${res1}`, isCorrect: false }
            ];

            return {
                room: 2,
                roomName: '第二密室：未來科幻量子實驗室',
                category: '判斷題 (去括號邏輯)',
                question: qText,
                formula: `100 - (${a} + ${b}) = ?`,
                options: this.shuffle(options),
                correctAnswer: correctOpt,
                hint: `連續減去兩個數，就等於減去這兩個數的「和」！若帶有括號，拿掉時加號要變號喔。`,
                steps: [
                    `式子 1：100 - (${a} + ${b}) = 100 - ${a + b} = ${res1}`,
                    `式子 2：100 - ${a} + ${b} = ${100 - a} + ${b} = ${res2}`,
                    `兩者相差 ${Math.abs(res2 - res1)}，結果不同！`
                ],
                points: 2000
            };
        } else {
            // who_is_right: Calculate 80 - 24 ÷ 4 + 6
            const div = this.randInt(3, 6);
            const quot = this.randInt(3, 8);
            const b = div * quot;
            const a = this.randInt(50, 90);
            const c = this.randInt(5, 15);
            const correctAns = a - quot + c;

            const qText = `【解題步驟評判】老師出了題目：「${a} - ${b} ÷ ${div} + ${c}」\n小智的做法：第一步先算 ${b} ÷ ${div} = ${quot}，第二步算 ${a} - ${quot} = ${a - quot}，第三步加 ${c} 得 ${correctAns}。\n皮卡的做法：第一步先算 ${a} - ${b}，再往下算。\n請問誰的方法合乎四則運算規則？`;

            const correctOpt = `小智正確！乘除在中間要優先算，之後同級的加減才由左至右算。`;
            const options = [
                { text: correctOpt, isCorrect: true },
                { text: `皮卡正確！算式一律從最左邊開始一步步算`, isCorrect: false },
                { text: `兩人都錯！應該先算後面的加法 ${quot} + ${c}`, isCorrect: false },
                { text: `兩人都對！四則運算先算誰都可以，答案一樣`, isCorrect: false }
            ];

            return {
                room: 2,
                roomName: '第二密室：未來科幻量子實驗室',
                category: '判斷題 (解法思維評判)',
                question: qText,
                formula: `${a} - ${b} ÷ ${div} + ${c}`,
                options: this.shuffle(options),
                correctAnswer: correctOpt,
                hint: `混合運算時：第一順位先算乘除，第二順位加減同級時「由左往右」依序運算。`,
                steps: [
                    `第一步：除法優先，${b} ÷ ${div} = ${quot}`,
                    `第二步：算式變為 ${a} - ${quot} + ${c}`,
                    `第三步：由左至右算，${a} - ${quot} = ${a - quot}，最後 ${a - quot} + ${c} = ${correctAns}。`
                ],
                points: 2000
            };
        }
    }

    // -------------------------------------------------------------
    // ROOM 3: 情境應用題 (Applied Contextual Story Problems)
    // -------------------------------------------------------------
    generateRoom3Question() {
        const scenarios = ['orchard_boxes', 'stationery_change', 'savings_diff', 'themepark_tickets', 'bakery_pack'];
        const type = this.choice(scenarios);

        if (type === 'orchard_boxes') {
            // (Total - Bad) / BoxSize * Price
            const boxSize = this.choice([6, 8, 10, 12]);
            const boxes = this.randInt(8, 25);
            const goodApples = boxSize * boxes;
            const badApples = this.randInt(12, 36);
            const totalApples = goodApples + badApples;
            const price = this.randInt(120, 280);
            const ans = boxes * price;

            const qText = `【神廟石板銘文：豐收祭典】\n豐收果園今天採收了 ${totalApples} 顆黃金蜜蘋果，檢查發現有 ${badApples} 顆被蟲蛀壞而丟棄。\n農夫將完好的蘋果每 ${boxSize} 顆裝成一盒禮盒，每盒以 ${price} 元賣出。\n如果全部禮盒都賣完，農夫共可收入多少元？`;

            const distractors = [
                Math.floor(totalApples / boxSize) * price, // forgot bad apples
                (boxes - 1) * price,
                ans + price * 2,
                Math.floor(totalApples - badApples) * boxSize
            ];

            const formula = `(${totalApples} - ${badApples}) ÷ ${boxSize} × ${price}`;
            const options = this.generateOptions(ans, distractors);

            return {
                room: 3,
                roomName: '第三密室：奇幻遠古神廟遺蹟',
                category: '情境應用題 (包裝與銷售)',
                question: qText,
                formula: formula,
                options: options.map(opt => ({
                    text: `${opt} 元`,
                    value: opt,
                    isCorrect: opt === ans
                })),
                correctAnswer: `${ans} 元`,
                hint: `解題思路：先求出「剩下完好的蘋果」有幾顆，再算出「可裝成幾盒」，最後乘以「每盒售價」！`,
                steps: [
                    `步驟 1：求完好蘋果數量：${totalApples} - ${badApples} = ${goodApples} (顆)`,
                    `步驟 2：求可裝成幾盒：${goodApples} ÷ ${boxSize} = ${boxes} (盒)`,
                    `步驟 3：求全部收入：${boxes} × ${price} = ${ans} (元)`,
                    `綜合算式：(${totalApples} - ${badApples}) ÷ ${boxSize} × ${price} = ${ans} (元)`
                ],
                points: 3000
            };
        } else if (type === 'stationery_change') {
            // Budget - (Count * PenPrice + NotebookPrice)
            const penCount = this.randInt(3, 7);
            const penPrice = this.choice([15, 20, 25, 30]);
            const bookPrice = this.randInt(45, 90);
            const totalCost = penCount * penPrice + bookPrice;
            const budget = Math.ceil((totalCost + this.randInt(30, 150)) / 100) * 100; // round to hundreds (e.g. 500)
            const change = budget - totalCost;

            const qText = `【神廟石板銘文：學者採購】\n古代學者小明帶了 1 張 ${budget} 元鈔票去文具閣採購，\n他買了 ${penCount} 枝鵝毛鋼筆，每枝 ${penPrice} 元；另外還買了 1 本 ${bookPrice} 元的魔法筆記本。\n請問結帳後，店家應該找回小明多少元？`;

            const distractors = [
                budget - (penPrice + bookPrice), // forgot pen count
                totalCost, // gave cost instead of change
                change + penPrice,
                budget - penCount * penPrice
            ];

            const formula = `${budget} - (${penCount} × ${penPrice} + ${bookPrice})`;
            const options = this.generateOptions(change, distractors);

            return {
                room: 3,
                roomName: '第三密室：奇幻遠古神廟遺蹟',
                category: '情境應用題 (購物與找零)',
                question: qText,
                formula: formula,
                options: options.map(opt => ({
                    text: `${opt} 元`,
                    value: opt,
                    isCorrect: opt === change
                })),
                correctAnswer: `${change} 元`,
                hint: `找零問題：找回金額 = 帶的錢 - (買筆花費 + 筆記本花費)。注意有括號！`,
                steps: [
                    `步驟 1：算買鋼筆花費：${penCount} × ${penPrice} = ${penCount * penPrice} (元)`,
                    `步驟 2：算總花費：${penCount * penPrice} + ${bookPrice} = ${totalCost} (元)`,
                    `步驟 3：算找回金額：${budget} - ${totalCost} = ${change} (元)`,
                    `綜合算式：${budget} - (${penCount} × ${penPrice} + ${bookPrice}) = ${change} (元)`
                ],
                points: 3000
            };
        } else if (type === 'savings_diff') {
            // (SaveA - SaveB) * Days
            const saveA = this.randInt(35, 60);
            const saveB = saveA - this.randInt(10, 20);
            const diffPerDay = saveA - saveB;
            const days = this.choice([10, 12, 14, 15, 20]);
            const totalDiff = diffPerDay * days;

            const qText = `【神廟石板銘文：兄弟儲蓄】\n哥哥每天在神廟存錢罐存入 ${saveA} 元，弟弟每天存入 ${saveB} 元。\n兩人都連續存了 ${days} 天，\n請問存完這 ${days} 天後，哥哥比弟弟一共多存了多少元？`;

            const distractors = [
                saveA * days,
                saveB * days,
                totalDiff + diffPerDay * 2,
                totalDiff - diffPerDay
            ];

            const formula = `(${saveA} - ${saveB}) × ${days}`;
            const options = this.generateOptions(totalDiff, distractors);

            return {
                room: 3,
                roomName: '第三密室：奇幻遠古神廟遺蹟',
                category: '情境應用題 (差額累積)',
                question: qText,
                formula: formula,
                options: options.map(opt => ({
                    text: `${opt} 元`,
                    value: opt,
                    isCorrect: opt === totalDiff
                })),
                correctAnswer: `${totalDiff} 元`,
                hint: `先算出每天哥哥比弟弟「多存多少元」，再乘上「天數」，計算會更簡單快速！`,
                steps: [
                    `方法一：先求每天差額：${saveA} - ${saveB} = ${diffPerDay} (元)`,
                    `再求 ${days} 天累積差距：${diffPerDay} × ${days} = ${totalDiff} (元)`,
                    `綜合算式：(${saveA} - ${saveB}) × ${days} = ${totalDiff} (元)`
                ],
                points: 3000
            };
        } else if (type === 'themepark_tickets') {
            // AdultCount * AdultPrice + ChildCount * ChildPrice
            const adultPrice = this.choice([250, 300, 350]);
            const childPrice = adultPrice - 100;
            const adultCount = this.randInt(2, 4);
            const childCount = this.randInt(3, 6);
            const total = adultPrice * adultCount + childPrice * childCount;

            const qText = `【神廟石板銘文：冒險門票】\n奇幻冒險島的成人門票一張 ${adultPrice} 元，學生優待票一張 ${childPrice} 元。\n數學探險隊一共購買了 ${adultCount} 張成人票與 ${childCount} 張學生票，\n請問探險隊一共需要支付多少門票費用？`;

            const distractors = [
                (adultPrice + childPrice) * (adultCount + childCount) / 2,
                adultPrice * adultCount,
                total + 100,
                total - childPrice
            ];

            const formula = `${adultPrice} × ${adultCount} + ${childPrice} × ${childCount}`;
            const options = this.generateOptions(total, distractors);

            return {
                room: 3,
                roomName: '第三密室：奇幻遠古神廟遺蹟',
                category: '情境應用題 (複合總價)',
                question: qText,
                formula: formula,
                options: options.map(opt => ({
                    text: `${opt} 元`,
                    value: opt,
                    isCorrect: opt === total
                })),
                correctAnswer: `${total} 元`,
                hint: `分別算出成人票總價與學生票總價，再將兩者相加！`,
                steps: [
                    `步驟 1：算成人票費用：${adultPrice} × ${adultCount} = ${adultPrice * adultCount} (元)`,
                    `步驟 2：算學生票費用：${childPrice} × ${childCount} = ${childPrice * childCount} (元)`,
                    `步驟 3：兩者相加：${adultPrice * adultCount} + ${childPrice * childCount} = ${total} (元)`
                ],
                points: 3000
            };
        } else {
            // Bakery packing: (Morning + Afternoon) / PackSize
            const packSize = this.choice([6, 8, 10]);
            const packs = this.randInt(12, 30);
            const totalCookies = packSize * packs;
            const morning = this.randInt(Math.floor(totalCookies * 0.3), Math.floor(totalCookies * 0.7));
            const afternoon = totalCookies - morning;

            const qText = `【神廟石板銘文：神聖烘焙】\n神廟烘焙師上午烘烤了 ${morning} 塊能量餅乾，下午烘烤了 ${afternoon} 塊能量餅乾。\n若要將今天所有烘烤好的餅乾每 ${packSize} 塊裝成一袋，\n請問一共可以裝成幾袋？`;

            const distractors = [
                Math.floor(morning / packSize) + Math.floor(afternoon / packSize) + 2,
                packs + 5,
                packs - 3,
                totalCookies
            ];

            const formula = `(${morning} + ${afternoon}) ÷ ${packSize}`;
            const options = this.generateOptions(packs, distractors);

            return {
                room: 3,
                roomName: '第三密室：奇幻遠古神廟遺蹟',
                category: '情境應用題 (合併平分)',
                question: qText,
                formula: formula,
                options: options.map(opt => ({
                    text: `${opt} 袋`,
                    value: opt,
                    isCorrect: opt === packs
                })),
                correctAnswer: `${packs} 袋`,
                hint: `先將上午與下午的餅乾數量相加算出「總共有幾塊」，再除以「每袋裝的數量」。括號一定要加！`,
                steps: [
                    `步驟 1：算餅乾總數：${morning} + ${afternoon} = ${totalCookies} (塊)`,
                    `步驟 2：算可裝幾袋：${totalCookies} ÷ ${packSize} = ${packs} (袋)`,
                    `綜合算式：(${morning} + ${afternoon}) ÷ ${packSize} = ${packs} (袋)`
                ],
                points: 3000
            };
        }
    }

    // Get question for specified room (1, 2, or 3)
    getQuestionForRoom(roomNumber) {
        if (roomNumber === 1) {
            return this.generateRoom1Question();
        } else if (roomNumber === 2) {
            return this.generateRoom2Question();
        } else {
            return this.generateRoom3Question();
        }
    }
}

window.mathEngine = new MathEngine();
