// room_textures.js - Procedural High-Definition Canvas Textures for 3 Distinct Rooms
// 100% Offline & Procedurally Rendered

class RoomTextures {
    constructor() {
        this.cache = {};
    }

    // Helper to create a canvas
    createCanvas(width, height) {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        return { canvas, ctx };
    }

    // Convert canvas to Three.js Texture
    canvasToTexture(canvas, repeatX = 1, repeatY = 1) {
        if (!window.THREE) return null;
        const texture = new THREE.CanvasTexture(canvas);
        texture.wrapS = THREE.RepeatWrapping;
        texture.wrapT = THREE.RepeatWrapping;
        texture.repeat.set(repeatX, repeatY);
        return texture;
    }

    // =========================================================================
    // ROOM 1: VINTAGE VICTORIAN MANOR (欧式古典學者莊園)
    // =========================================================================

    // Polished Herringbone Wood Parquet Floor
    getVintageWoodFloor() {
        if (this.cache['woodFloor']) return this.cache['woodFloor'];
        const { canvas, ctx } = this.createCanvas(1024, 1024);

        // Base warm wood tone
        ctx.fillStyle = '#4a2511';
        ctx.fillRect(0, 0, 1024, 1024);

        // Plank dimensions
        const plankW = 128;
        const plankH = 32;

        for (let y = 0; y < 1024; y += plankH) {
            for (let x = 0; x < 1024; x += plankW) {
                const shift = (Math.floor(y / plankH) % 2) * (plankW / 2);
                const px = (x + shift) % 1024;

                // Random wood tone variation
                const woodTone = 30 + Math.floor(Math.random() * 25);
                const woodRed = 60 + Math.floor(Math.random() * 30);
                ctx.fillStyle = `rgb(${woodRed}, ${woodTone}, 15)`;
                ctx.fillRect(px, y, plankW - 2, plankH - 2);

                // Wood grain lines
                ctx.strokeStyle = `rgba(30, 15, 5, 0.25)`;
                ctx.lineWidth = 1;
                for (let g = 0; g < 4; g++) {
                    const gy = y + 4 + g * 7 + Math.random() * 3;
                    ctx.beginPath();
                    ctx.moveTo(px, gy);
                    ctx.bezierCurveTo(px + 40, gy + (Math.random() - 0.5) * 4, px + 80, gy + (Math.random() - 0.5) * 4, px + plankW - 2, gy);
                    ctx.stroke();
                }

                // Plank edge shadow
                ctx.fillStyle = 'rgba(15, 5, 0, 0.6)';
                ctx.fillRect(px, y + plankH - 2, plankW, 2);
                ctx.fillRect(px + plankW - 2, y, 2, plankH);
            }
        }

        // Parquet gloss gradient
        const glossGrad = ctx.createLinearGradient(0, 0, 1024, 1024);
        glossGrad.addColorStop(0, 'rgba(255, 220, 180, 0.08)');
        glossGrad.addColorStop(0.5, 'rgba(0, 0, 0, 0)');
        glossGrad.addColorStop(1, 'rgba(255, 200, 150, 0.05)');
        ctx.fillStyle = glossGrad;
        ctx.fillRect(0, 0, 1024, 1024);

        const tex = this.canvasToTexture(canvas, 4, 4);
        this.cache['woodFloor'] = tex;
        return tex;
    }

    // Victorian Floral Damask Wallpaper (Like the reference photo)
    getVictorianWallpaper() {
        if (this.cache['victorianWallpaper']) return this.cache['victorianWallpaper'];
        const { canvas, ctx } = this.createCanvas(1024, 1024);

        // Elegant olive-green/vintage brocade base
        const grad = ctx.createRadialGradient(512, 512, 100, 512, 512, 700);
        grad.addColorStop(0, '#3a4433');
        grad.addColorStop(1, '#242d1f');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 1024, 1024);

        // Subtle fabric texture noise
        for (let i = 0; i < 20000; i++) {
            ctx.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.04)';
            ctx.fillRect(Math.random() * 1024, Math.random() * 1024, 2, 2);
        }

        // Damask Pattern repeats
        const step = 128;
        ctx.fillStyle = 'rgba(75, 95, 65, 0.45)';
        ctx.strokeStyle = 'rgba(165, 140, 75, 0.35)'; // Antique gold outline
        ctx.lineWidth = 1.5;

        for (let y = 0; y < 1024; y += step) {
            for (let x = 0; x < 1024; x += step) {
                const cx = x + step / 2;
                const cy = y + step / 2;

                // Center Fleur-de-lis / rosette
                ctx.beginPath();
                ctx.arc(cx, cy, 22, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();

                // Decorative floral leaves
                for (let a = 0; a < 4; a++) {
                    const angle = (a * Math.PI) / 2;
                    const lx = cx + Math.cos(angle) * 32;
                    const ly = cy + Math.sin(angle) * 32;

                    ctx.beginPath();
                    ctx.ellipse(lx, ly, 16, 8, angle, 0, Math.PI * 2);
                    ctx.fill();
                    ctx.stroke();
                }

                // Golden dot center
                ctx.fillStyle = '#d4af37';
                ctx.beginPath();
                ctx.arc(cx, cy, 4, 0, Math.PI * 2);
                ctx.fill();
                ctx.fillStyle = 'rgba(75, 95, 65, 0.45)';
            }
        }

        // Vintage vignetting on edges
        const vig = ctx.createRadialGradient(512, 512, 400, 512, 512, 750);
        vig.addColorStop(0, 'rgba(0,0,0,0)');
        vig.addColorStop(1, 'rgba(15,20,10,0.6)');
        ctx.fillStyle = vig;
        ctx.fillRect(0, 0, 1024, 1024);

        const tex = this.canvasToTexture(canvas, 3, 2);
        this.cache['victorianWallpaper'] = tex;
        return tex;
    }

    // Vintage Ceiling with Stucco Plaster
    getVintageCeiling() {
        if (this.cache['vintageCeiling']) return this.cache['vintageCeiling'];
        const { canvas, ctx } = this.createCanvas(512, 512);

        ctx.fillStyle = '#2d2722';
        ctx.fillRect(0, 0, 512, 512);

        // Wooden beams
        ctx.fillStyle = '#1c130c';
        for (let x = 0; x < 512; x += 128) {
            ctx.fillRect(x, 0, 24, 512);
        }

        const tex = this.canvasToTexture(canvas, 2, 2);
        this.cache['vintageCeiling'] = tex;
        return tex;
    }

    // Fireplace Stone & Charred Bricks
    getFireplaceBrick() {
        if (this.cache['fireplaceBrick']) return this.cache['fireplaceBrick'];
        const { canvas, ctx } = this.createCanvas(512, 512);

        ctx.fillStyle = '#22201e';
        ctx.fillRect(0, 0, 512, 512);

        const bw = 64;
        const bh = 32;
        for (let y = 0; y < 512; y += bh) {
            const shift = (Math.floor(y / bh) % 2) * (bw / 2);
            for (let x = -bw; x < 512 + bw; x += bw) {
                const brickX = x + shift;
                const r = 90 + Math.floor(Math.random() * 30);
                const g = 60 + Math.floor(Math.random() * 20);
                const b = 45 + Math.floor(Math.random() * 15);
                ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
                ctx.fillRect(brickX + 2, y + 2, bw - 4, bh - 4);
            }
        }

        // Fireplace soot/ash in center bottom
        const soot = ctx.createRadialGradient(256, 400, 30, 256, 400, 220);
        soot.addColorStop(0, 'rgba(10, 5, 0, 0.95)');
        soot.addColorStop(1, 'rgba(10, 5, 0, 0)');
        ctx.fillStyle = soot;
        ctx.fillRect(0, 0, 512, 512);

        const tex = this.canvasToTexture(canvas);
        this.cache['fireplaceBrick'] = tex;
        return tex;
    }

    // Oil Painting Portrait with Gilded Gold Frame
    getOilPaintingTexture() {
        if (this.cache['oilPainting']) return this.cache['oilPainting'];
        const { canvas, ctx } = this.createCanvas(512, 700);

        // Gilded Ornate Outer Frame
        const frameGrad = ctx.createLinearGradient(0, 0, 512, 700);
        frameGrad.addColorStop(0, '#d4af37');
        frameGrad.addColorStop(0.3, '#aa8c2c');
        frameGrad.addColorStop(0.7, '#6b5416');
        frameGrad.addColorStop(1, '#e5c158');
        ctx.fillStyle = frameGrad;
        ctx.fillRect(0, 0, 512, 700);

        // Frame bevel
        ctx.lineWidth = 14;
        ctx.strokeStyle = '#382a08';
        ctx.strokeRect(7, 7, 512 - 14, 700 - 14);

        // Frame inner rim
        ctx.lineWidth = 6;
        ctx.strokeStyle = '#ffe57f';
        ctx.strokeRect(30, 30, 512 - 60, 700 - 60);

        // Canvas Area (Mystic classical portrait)
        const canvasX = 40;
        const canvasY = 40;
        const canvasW = 512 - 80;
        const canvasH = 700 - 80;

        const bg = ctx.createRadialGradient(256, 300, 40, 256, 350, 300);
        bg.addColorStop(0, '#3d2f23');
        bg.addColorStop(1, '#0e0b08');
        ctx.fillStyle = bg;
        ctx.fillRect(canvasX, canvasY, canvasW, canvasH);

        // Mystical scholar silhouette with glowing ancient compass
        ctx.fillStyle = '#17120e';
        // Head & hat
        ctx.beginPath();
        ctx.arc(256, 240, 55, 0, Math.PI * 2);
        ctx.fill();

        // Scholar robe
        ctx.beginPath();
        ctx.moveTo(180, 560);
        ctx.lineTo(210, 290);
        ctx.lineTo(302, 290);
        ctx.lineTo(332, 560);
        ctx.closePath();
        ctx.fill();

        // Glowing Golden Geometry / Math Compass in hand
        ctx.strokeStyle = '#ffcc00';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(256, 390, 45, 0, Math.PI * 2);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(256, 335);
        ctx.lineTo(256, 445);
        ctx.moveTo(201, 390);
        ctx.lineTo(311, 390);
        ctx.stroke();

        // Greek / Math Symbols floating around
        ctx.fillStyle = '#ffec99';
        ctx.font = 'bold 24px serif';
        ctx.fillText('π', 190, 350);
        ctx.fillText('∑', 310, 350);
        ctx.fillText('∫', 195, 430);
        ctx.fillText('∞', 305, 430);

        // Frame caption plate
        ctx.fillStyle = '#1c1508';
        ctx.fillRect(160, 620, 192, 35);
        ctx.strokeStyle = '#ffd700';
        ctx.lineWidth = 2;
        ctx.strokeRect(160, 620, 192, 35);
        ctx.fillStyle = '#ffd700';
        ctx.font = 'bold 15px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('時空四則運算大宗師', 256, 644);

        const tex = this.canvasToTexture(canvas);
        this.cache['oilPainting'] = tex;
        return tex;
    }

    // Antique Wooden Door with Lock Vault
    getVintageDoor() {
        if (this.cache['vintageDoor']) return this.cache['vintageDoor'];
        const { canvas, ctx } = this.createCanvas(512, 1024);

        // Heavy dark oak wood
        ctx.fillStyle = '#3a1e0d';
        ctx.fillRect(0, 0, 512, 1024);

        // Wood grain
        ctx.fillStyle = '#291408';
        for (let i = 0; i < 4; i++) {
            const px = 20 + i * 120;
            ctx.fillRect(px, 40, 105, 420);
            ctx.fillRect(px, 500, 105, 480);
        }

        // Iron arch straps
        ctx.fillStyle = '#222';
        ctx.fillRect(0, 180, 512, 36);
        ctx.fillRect(0, 780, 512, 36);

        // Iron rivets
        ctx.fillStyle = '#777';
        for (let rx = 30; rx < 512; rx += 70) {
            ctx.beginPath();
            ctx.arc(rx, 198, 8, 0, Math.PI * 2);
            ctx.arc(rx, 798, 8, 0, Math.PI * 2);
            ctx.fill();
        }

        // Antique Brass Keypad / Math Puzzle Lock Plate in Center
        ctx.fillStyle = '#c59b27';
        ctx.fillRect(180, 420, 152, 160);
        ctx.lineWidth = 6;
        ctx.strokeStyle = '#5a4208';
        ctx.strokeRect(180, 420, 152, 160);

        ctx.fillStyle = '#111';
        ctx.fillRect(200, 440, 112, 60);

        // Glowing digits indicator on lock
        ctx.fillStyle = '#00ff88';
        ctx.font = 'bold 22px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('???', 256, 480);

        // Keyhole / Handle
        ctx.fillStyle = '#222';
        ctx.beginPath();
        ctx.arc(256, 535, 12, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillRect(251, 535, 10, 24);

        const tex = this.canvasToTexture(canvas);
        this.cache['vintageDoor'] = tex;
        return tex;
    }

    // =========================================================================
    // ROOM 2: CYBERPUNK SCI-FI QUANTUM LAB (未來科幻量子實驗室)
    // =========================================================================

    // Cyberpunk Hexagonal & Neon Grid Floor
    getCyberFloor() {
        if (this.cache['cyberFloor']) return this.cache['cyberFloor'];
        const { canvas, ctx } = this.createCanvas(1024, 1024);

        // Dark metallic carbon base
        ctx.fillStyle = '#0c111c';
        ctx.fillRect(0, 0, 1024, 1024);

        // Grid lines
        const step = 64;
        ctx.strokeStyle = '#1b2a4a';
        ctx.lineWidth = 2;

        for (let x = 0; x <= 1024; x += step) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, 1024);
            ctx.stroke();
        }
        for (let y = 0; y <= 1024; y += step) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(1024, y);
            ctx.stroke();
        }

        // Glowing Cyan & Magenta Circuit Pathways
        ctx.strokeStyle = '#00f0ff';
        ctx.lineWidth = 4;
        ctx.shadowColor = '#00f0ff';
        ctx.shadowBlur = 12;

        for (let line = 0; line < 8; line++) {
            const startX = (line * 137) % 1024;
            const startY = (line * 219) % 1024;
            ctx.beginPath();
            ctx.moveTo(startX, startY);
            ctx.lineTo(startX + 128, startY);
            ctx.lineTo(startX + 192, startY + 128);
            ctx.stroke();

            // Circuit node
            ctx.fillStyle = '#00f0ff';
            ctx.beginPath();
            ctx.arc(startX + 192, startY + 128, 6, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.shadowBlur = 0; // Reset

        // Hazard stripes in corners
        ctx.fillStyle = '#ffaa00';
        for (let i = 0; i < 6; i++) {
            ctx.beginPath();
            ctx.moveTo(i * 30, 0);
            ctx.lineTo(i * 30 + 15, 0);
            ctx.lineTo(0, i * 30 + 15);
            ctx.lineTo(0, i * 30);
            ctx.fill();
        }

        const tex = this.canvasToTexture(canvas, 4, 4);
        this.cache['cyberFloor'] = tex;
        return tex;
    }

    // Sci-Fi Metallic Panels & Neon Tube Walls
    getCyberWall() {
        if (this.cache['cyberWall']) return this.cache['cyberWall'];
        const { canvas, ctx } = this.createCanvas(1024, 1024);

        // Titanium steel gradient
        const bgGrad = ctx.createLinearGradient(0, 0, 1024, 1024);
        bgGrad.addColorStop(0, '#101726');
        bgGrad.addColorStop(0.5, '#090d15');
        bgGrad.addColorStop(1, '#151f33');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, 1024, 1024);

        // Giant metal wall panel divisions
        ctx.strokeStyle = '#223554';
        ctx.lineWidth = 6;
        ctx.strokeRect(30, 30, 964, 460);
        ctx.strokeRect(30, 520, 964, 470);

        // Glowing Blue & Purple Neon strip
        ctx.fillStyle = '#00ffff';
        ctx.shadowColor = '#00e1ff';
        ctx.shadowBlur = 15;
        ctx.fillRect(30, 500, 964, 10);
        ctx.shadowBlur = 0;

        // Server rack ventilation louvers
        ctx.fillStyle = '#05080e';
        for (let v = 0; v < 14; v++) {
            ctx.fillRect(80, 100 + v * 24, 380, 12);
        }

        // Status Indicators & Holographic Warning
        ctx.fillStyle = '#ff0055';
        ctx.shadowColor = '#ff0055';
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(600, 140, 10, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#00ff88';
        ctx.shadowColor = '#00ff88';
        ctx.beginPath();
        ctx.arc(640, 140, 10, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ffaa00';
        ctx.shadowColor = '#ffaa00';
        ctx.beginPath();
        ctx.arc(680, 140, 10, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Sci-Fi Tech Typography
        ctx.font = 'bold 20px monospace';
        ctx.fillStyle = '#3a6699';
        ctx.fillText('QUANTUM COMPUTING LAB // SEC-02', 520, 200);
        ctx.fillText('LOGIC VERIFICATION CORE', 520, 230);
        ctx.fillText('STATUS: LOCKED [MATH PUZZLE REQUIRED]', 520, 260);

        const tex = this.canvasToTexture(canvas, 2, 2);
        this.cache['cyberWall'] = tex;
        return tex;
    }

    // Sci-Fi Hydraulic Blast Door
    getCyberDoor() {
        if (this.cache['cyberDoor']) return this.cache['cyberDoor'];
        const { canvas, ctx } = this.createCanvas(512, 1024);

        ctx.fillStyle = '#080d16';
        ctx.fillRect(0, 0, 512, 1024);

        // Armored sliding door plates
        ctx.strokeStyle = '#1e3352';
        ctx.lineWidth = 10;
        ctx.strokeRect(20, 20, 472, 984);

        // Center split line
        ctx.strokeStyle = '#00e1ff';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(256, 20);
        ctx.lineTo(256, 1004);
        ctx.stroke();

        // Holographic Lock Interface in Center
        ctx.fillStyle = '#0f243b';
        ctx.fillRect(130, 400, 252, 224);
        ctx.strokeStyle = '#00e1ff';
        ctx.lineWidth = 4;
        ctx.strokeRect(130, 400, 252, 224);

        // Holographic terminal screen
        ctx.fillStyle = '#03101c';
        ctx.fillRect(150, 420, 212, 184);

        ctx.fillStyle = '#00f0ff';
        ctx.font = 'bold 22px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('QUANTUM LOCK', 256, 460);

        ctx.fillStyle = '#ff0055';
        ctx.font = 'bold 26px monospace';
        ctx.fillText('ACCESS DENIED', 256, 510);

        ctx.fillStyle = '#00ffaa';
        ctx.font = '16px monospace';
        ctx.fillText('[ 點擊進行邏輯判斷解鎖 ]', 256, 560);

        const tex = this.canvasToTexture(canvas);
        this.cache['cyberDoor'] = tex;
        return tex;
    }

    // =========================================================================
    // ROOM 3: MYSTIC ANCIENT TEMPLE (奇幻遠古神廟遺蹟)
    // =========================================================================

    // Ancient Rune Temple Cobblestone Floor
    getTempleStoneFloor() {
        if (this.cache['templeStoneFloor']) return this.cache['templeStoneFloor'];
        const { canvas, ctx } = this.createCanvas(1024, 1024);

        // Deep ancient stone base
        ctx.fillStyle = '#222326';
        ctx.fillRect(0, 0, 1024, 1024);

        // Giant irregular flagstones
        const tileSize = 128;
        for (let y = 0; y < 1024; y += tileSize) {
            for (let x = 0; x < 1024; x += tileSize) {
                const stoneTone = 38 + Math.floor(Math.random() * 20);
                ctx.fillStyle = `rgb(${stoneTone}, ${stoneTone + 3}, ${stoneTone - 2})`;
                ctx.fillRect(x + 3, y + 3, tileSize - 6, tileSize - 6);

                // Moss stains
                if (Math.random() > 0.4) {
                    ctx.fillStyle = 'rgba(40, 80, 35, 0.4)';
                    ctx.beginPath();
                    ctx.arc(x + Math.random() * tileSize, y + Math.random() * tileSize, 18 + Math.random() * 25, 0, Math.PI * 2);
                    ctx.fill();
                }
            }
        }

        // Glowing Mystic Rune Inscriptions on Floor
        ctx.strokeStyle = 'rgba(180, 100, 255, 0.6)';
        ctx.lineWidth = 3;
        ctx.shadowColor = '#bd00ff';
        ctx.shadowBlur = 10;

        // Sacred geometry circle
        ctx.beginPath();
        ctx.arc(512, 512, 380, 0, Math.PI * 2);
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(512, 512, 260, 0, Math.PI * 2);
        ctx.stroke();

        // 8-point mystical compass
        for (let i = 0; i < 8; i++) {
            const rad = (i * Math.PI) / 4;
            ctx.beginPath();
            ctx.moveTo(512, 512);
            ctx.lineTo(512 + Math.cos(rad) * 380, 512 + Math.sin(rad) * 380);
            ctx.stroke();
        }
        ctx.shadowBlur = 0;

        const tex = this.canvasToTexture(canvas, 3, 3);
        this.cache['templeStoneFloor'] = tex;
        return tex;
    }

    // Weathered Mossy Rune Stone Wall
    getTempleWall() {
        if (this.cache['templeWall']) return this.cache['templeWall'];
        const { canvas, ctx } = this.createCanvas(1024, 1024);

        ctx.fillStyle = '#2b2c28';
        ctx.fillRect(0, 0, 1024, 1024);

        // Huge stone megaliths
        const blockW = 256;
        const blockH = 128;

        for (let y = 0; y < 1024; y += blockH) {
            const shift = (Math.floor(y / blockH) % 2) * (blockW / 2);
            for (let x = -blockW; x < 1024 + blockW; x += blockW) {
                const bx = x + shift;
                const tone = 42 + Math.floor(Math.random() * 22);
                ctx.fillStyle = `rgb(${tone}, ${tone + 4}, ${tone - 2})`;
                ctx.fillRect(bx + 4, y + 4, blockW - 8, blockH - 8);

                // Cracks in stone
                if (Math.random() > 0.6) {
                    ctx.strokeStyle = '#181916';
                    ctx.lineWidth = 2;
                    ctx.beginPath();
                    ctx.moveTo(bx + 20, y + 15);
                    ctx.lineTo(bx + 60, y + 45);
                    ctx.lineTo(bx + 110, y + 38);
                    ctx.stroke();
                }

                // Carved glowing glyphs on certain stones
                if (Math.random() > 0.7) {
                    ctx.strokeStyle = 'rgba(255, 200, 50, 0.75)';
                    ctx.shadowColor = '#ffa500';
                    ctx.shadowBlur = 8;
                    ctx.strokeRect(bx + 80, y + 30, 40, 40);
                    ctx.beginPath();
                    ctx.arc(bx + 100, y + 50, 12, 0, Math.PI * 2);
                    ctx.stroke();
                    ctx.shadowBlur = 0;
                }
            }
        }

        // Overgrown Ivy / Moss Vines from top
        ctx.fillStyle = 'rgba(35, 75, 28, 0.7)';
        for (let v = 0; v < 16; v++) {
            const vx = v * 64 + Math.random() * 20;
            const vLen = 120 + Math.random() * 250;
            ctx.beginPath();
            ctx.ellipse(vx, vLen / 2, 20, vLen / 2, 0, 0, Math.PI * 2);
            ctx.fill();
        }

        const tex = this.canvasToTexture(canvas, 2, 2);
        this.cache['templeWall'] = tex;
        return tex;
    }

    // Grand Ancient Sun Vault Door
    getTempleDoor() {
        if (this.cache['templeDoor']) return this.cache['templeDoor'];
        const { canvas, ctx } = this.createCanvas(512, 1024);

        ctx.fillStyle = '#1e1c1a';
        ctx.fillRect(0, 0, 512, 1024);

        // Massive carved arch
        ctx.strokeStyle = '#4e4337';
        ctx.lineWidth = 16;
        ctx.strokeRect(20, 20, 472, 984);

        // Mystic Rotating Stone Dial
        const dialGrad = ctx.createRadialGradient(256, 512, 30, 256, 512, 180);
        dialGrad.addColorStop(0, '#94702e');
        dialGrad.addColorStop(0.7, '#423315');
        dialGrad.addColorStop(1, '#1b1509');
        ctx.fillStyle = dialGrad;
        ctx.beginPath();
        ctx.arc(256, 512, 160, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#ffd700';
        ctx.lineWidth = 6;
        ctx.shadowColor = '#ffbb00';
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.arc(256, 512, 160, 0, Math.PI * 2);
        ctx.stroke();

        // 12 Constellation Rays
        for (let i = 0; i < 12; i++) {
            const ang = (i * Math.PI) / 6;
            ctx.beginPath();
            ctx.moveTo(256 + Math.cos(ang) * 90, 512 + Math.sin(ang) * 90);
            ctx.lineTo(256 + Math.cos(ang) * 150, 512 + Math.sin(ang) * 150);
            ctx.stroke();
        }
        ctx.shadowBlur = 0;

        // Glowing Ancient Inscription
        ctx.fillStyle = '#fff2a8';
        ctx.font = 'bold 24px serif';
        ctx.textAlign = 'center';
        ctx.fillText('❖ 大師之印 ❖', 256, 490);
        ctx.font = 'bold 18px serif';
        ctx.fillText('解鎖遠古情境謎題', 256, 540);

        const tex = this.canvasToTexture(canvas);
        this.cache['templeDoor'] = tex;
        return tex;
    }
}

window.roomTextures = new RoomTextures();
