// sound_engine.js - Web Audio API Procedural Sound Synthesizer
// 100% Standalone, no external audio files required!

class SoundEngine {
    constructor() {
        this.ctx = null;
        this.enabled = true;
        this.bgmOsc = null;
        this.bgmGain = null;
        this.currentRoomTheme = null;
    }

    init() {
        if (!this.ctx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
                this.ctx = new AudioContext();
            }
        }
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    playClick() {
        if (!this.enabled) return;
        this.init();
        if (!this.ctx) return;

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, this.ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(400, this.ctx.currentTime + 0.05);

        gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.05);
    }

    playPickup() {
        if (!this.enabled) return;
        this.init();
        if (!this.ctx) return;

        // Sparkling arpeggio: C5, E5, G5, C6
        const notes = [523.25, 659.25, 783.99, 1046.50];
        notes.forEach((freq, idx) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            const startTime = this.ctx.currentTime + idx * 0.06;

            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, startTime);

            gain.gain.setValueAtTime(0.18, startTime);
            gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.15);

            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(startTime);
            osc.stop(startTime + 0.15);
        });
    }

    playUseItem() {
        if (!this.enabled) return;
        this.init();
        if (!this.ctx) return;

        // Magical pulse
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(300, this.ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(900, this.ctx.currentTime + 0.25);

        gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.25);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.25);
    }

    playCorrect() {
        if (!this.enabled) return;
        this.init();
        if (!this.ctx) return;

        // Major chord fanfare: C5, G5, C6
        const chord = [523.25, 659.25, 783.99, 1046.50];
        chord.forEach((freq, idx) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            const start = this.ctx.currentTime + idx * 0.08;

            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, start);

            gain.gain.setValueAtTime(0.2, start);
            gain.gain.exponentialRampToValueAtTime(0.001, start + 0.35);

            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(start);
            osc.stop(start + 0.35);
        });
    }

    playWrong() {
        if (!this.enabled) return;
        this.init();
        if (!this.ctx) return;

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(150, this.ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(90, this.ctx.currentTime + 0.25);

        gain.gain.setValueAtTime(0.18, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.25);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.25);
    }

    playDoorOpen() {
        if (!this.enabled) return;
        this.init();
        if (!this.ctx) return;

        // Low heavy mechanical / stone sliding rumble
        const bufferSize = this.ctx.sampleRate * 1.0;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
        }

        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(180, this.ctx.currentTime);
        filter.frequency.exponentialRampToValueAtTime(60, this.ctx.currentTime + 0.9);

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.3, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.9);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        noise.start();
        noise.stop(this.ctx.currentTime + 0.9);

        // Add a rising mechanical pitch
        const osc = this.ctx.createOscillator();
        const oscGain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(200, this.ctx.currentTime + 0.2);
        osc.frequency.exponentialRampToValueAtTime(600, this.ctx.currentTime + 0.8);
        oscGain.gain.setValueAtTime(0.15, this.ctx.currentTime + 0.2);
        oscGain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.8);

        osc.connect(oscGain);
        oscGain.connect(this.ctx.destination);
        osc.start(this.ctx.currentTime + 0.2);
        osc.stop(this.ctx.currentTime + 0.8);
    }

    playFanfare() {
        if (!this.enabled) return;
        this.init();
        if (!this.ctx) return;

        // Royal victory fanfare: G4, C5, E5, G5 -> High C6 sustain
        const melody = [
            { f: 392.00, d: 0.15 }, // G4
            { f: 523.25, d: 0.15 }, // C5
            { f: 659.25, d: 0.15 }, // E5
            { f: 783.99, d: 0.35 }, // G5
            { f: 659.25, d: 0.12 }, // E5
            { f: 783.99, d: 0.12 }, // G5
            { f: 1046.50, d: 0.8 }  // C6
        ];

        let timeOffset = 0;
        melody.forEach(note => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            const start = this.ctx.currentTime + timeOffset;

            osc.type = 'triangle';
            osc.frequency.setValueAtTime(note.f, start);

            gain.gain.setValueAtTime(0.25, start);
            gain.gain.exponentialRampToValueAtTime(0.001, start + note.d);

            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(start);
            osc.stop(start + note.d);

            timeOffset += note.d * 0.85;
        });
    }

    playAmbient(roomIndex) {
        if (!this.enabled) return;
        this.init();
        if (!this.ctx) return;

        this.stopAmbient();

        try {
            // Subtle ambient soundscape
            const now = this.ctx.currentTime;
            this.bgmGain = this.ctx.createGain();
            this.bgmGain.gain.setValueAtTime(0.04, now);
            this.bgmGain.connect(this.ctx.destination);

            this.bgmOsc = this.ctx.createOscillator();
            if (roomIndex === 0) {
                // Room 1: Warm low drone (fireplace hearth mood)
                this.bgmOsc.type = 'sine';
                this.bgmOsc.frequency.setValueAtTime(110, now); // A2
            } else if (roomIndex === 1) {
                // Room 2: Sci-fi cyber drone
                this.bgmOsc.type = 'sawtooth';
                this.bgmOsc.frequency.setValueAtTime(82.4, now); // E2
                const filter = this.ctx.createBiquadFilter();
                filter.type = 'lowpass';
                filter.frequency.setValueAtTime(220, now);
                this.bgmOsc.connect(filter);
                filter.connect(this.bgmGain);
                this.bgmOsc.start();
                return;
            } else {
                // Room 3: Mystic ethereal ancient temple
                this.bgmOsc.type = 'triangle';
                this.bgmOsc.frequency.setValueAtTime(146.83, now); // D3
            }

            this.bgmOsc.connect(this.bgmGain);
            this.bgmOsc.start();
        } catch (e) {
            console.warn("Ambient sound init error:", e);
        }
    }

    stopAmbient() {
        if (this.bgmOsc) {
            try {
                this.bgmOsc.stop();
                this.bgmOsc.disconnect();
            } catch (e) {}
            this.bgmOsc = null;
        }
        if (this.bgmGain) {
            try {
                this.bgmGain.disconnect();
            } catch (e) {}
            this.bgmGain = null;
        }
    }

    toggleMute() {
        this.enabled = !this.enabled;
        if (!this.enabled) {
            this.stopAmbient();
        }
        return this.enabled;
    }
}

window.soundEngine = new SoundEngine();
