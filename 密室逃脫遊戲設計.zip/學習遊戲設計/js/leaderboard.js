// leaderboard.js - LocalStorage Leaderboard & Dynamic Certificate Generator

class LeaderboardManager {
    constructor() {
        this.storageKey = 'escape_math_leaderboard_v1';
        this.defaultLeaderboard = [
            { name: '柯南小偵探', score: 9850, certs: 3, timeStr: '03:15', date: '2026/09/28' },
            { name: '愛因斯坦二世', score: 9200, certs: 3, timeStr: '03:42', date: '2026/09/29' },
            { name: '數學速算超人', score: 8650, certs: 3, timeStr: '04:10', date: '2026/10/01' },
            { name: '快樂小學霸', score: 7900, certs: 3, timeStr: '04:55', date: '2026/10/02' },
            { name: '四年甲班小萱', score: 7100, certs: 2, timeStr: '05:30', date: '2026/10/03' },
            { name: '時空冒險家', score: 6500, certs: 2, timeStr: '06:05', date: '2026/10/04' }
        ];
    }

    getScores() {
        try {
            const raw = localStorage.getItem(this.storageKey);
            if (!raw) {
                this.saveScores(this.defaultLeaderboard);
                return this.defaultLeaderboard;
            }
            return JSON.parse(raw);
        } catch (e) {
            return this.defaultLeaderboard;
        }
    }

    saveScores(list) {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(list));
        } catch (e) {
            console.warn("Storage save error:", e);
        }
    }

    addRecord(name, score, certs, seconds) {
        const list = this.getScores();
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        const today = new Date().toLocaleDateString('zh-TW');

        const newEntry = {
            name: name || '無名冒險家',
            score: Math.max(0, score),
            certs: certs,
            timeStr: timeStr,
            date: today,
            isCurrent: true
        };

        // Remove previous isCurrent marks
        list.forEach(item => item.isCurrent = false);

        list.push(newEntry);
        // Sort descending by score, then ascending by time
        list.sort((a, b) => b.score - a.score);

        // Keep top 20
        const trimmed = list.slice(0, 20);
        this.saveScores(trimmed);
        return trimmed;
    }

    // Dynamic High-Resolution Canvas Certificate Generator (800x600)
    generateCertificate(certType, playerName, score, clearTimeStr) {
        const canvas = document.createElement('canvas');
        canvas.width = 1000;
        canvas.height = 700;
        const ctx = canvas.getContext('2d');

        // Config per certification level
        let levelTitle = '';
        let badgeColor = '';
        let certSubtitle = '';
        let certDesc = '';

        if (certType === 1) {
            levelTitle = '四則運算【初級證照】';
            badgeColor = '#cd7f32'; // Bronze/Amber
            certSubtitle = 'ELEMENTARY ARITHMETIC LICENSE';
            certDesc = '恭喜通過第一密室考驗！熟練掌握四則運算「先乘除後加減」與「括號優先」之核心運算規則。特頒此證以資表彰！';
        } else if (certType === 2) {
            levelTitle = '四則運算【進階證照】';
            badgeColor = '#00c3ff'; // Cyber Cyan/Silver
            certSubtitle = 'ADVANCED LOGIC & CALCULATION LICENSE';
            certDesc = '恭喜通過第二密室考驗！精準洞悉四則運算規律、去括號性質與乘法分配律，具備卓越之邏輯辨識與驗證能力！';
        } else {
            levelTitle = '四則運算【大師證照】';
            badgeColor = '#ffd700'; // Grandmaster Gold
            certSubtitle = 'GRANDMASTER APPLIED ARITHMETIC LICENSE';
            certDesc = '恭喜完美突破三大時空密室！圓滿破解生活情境應用題，融會貫通四則運算真諦，榮登國小四年級最高榮譽之殿堂！';
        }

        // 1. Certificate Background Paper Gradient
        const bgGrad = ctx.createLinearGradient(0, 0, 1000, 700);
        bgGrad.addColorStop(0, '#fefbf3');
        bgGrad.addColorStop(0.5, '#fbf4e2');
        bgGrad.addColorStop(1, '#f5e9c9');
        ctx.fillStyle = bgGrad;
        ctx.fillRect(0, 0, 1000, 700);

        // Subtle parchment pattern texture
        ctx.fillStyle = 'rgba(160, 130, 90, 0.05)';
        for (let i = 0; i < 8000; i++) {
            ctx.fillRect(Math.random() * 1000, Math.random() * 700, 2, 2);
        }

        // 2. Ornate Golden Outer Borders
        ctx.strokeStyle = badgeColor;
        ctx.lineWidth = 14;
        ctx.strokeRect(25, 25, 950, 650);

        ctx.strokeStyle = '#4a3718';
        ctx.lineWidth = 3;
        ctx.strokeRect(38, 38, 924, 624);

        ctx.strokeStyle = badgeColor;
        ctx.lineWidth = 2;
        ctx.strokeRect(46, 46, 908, 608);

        // Corner Ornaments
        const corners = [
            { x: 50, y: 50 },
            { x: 950, y: 50 },
            { x: 50, y: 650 },
            { x: 950, y: 650 }
        ];
        corners.forEach(c => {
            ctx.fillStyle = badgeColor;
            ctx.beginPath();
            ctx.arc(c.x, c.y, 20, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#4a3718';
            ctx.beginPath();
            ctx.arc(c.x, c.y, 8, 0, Math.PI * 2);
            ctx.fill();
        });

        // 3. Header
        ctx.textAlign = 'center';
        ctx.fillStyle = '#6b4c1b';
        ctx.font = 'bold 22px "Microsoft JhengHei", "PingFang TC", sans-serif';
        ctx.fillText('❖ 時空數學密室逃脫榮譽認證 ❖', 500, 95);

        ctx.fillStyle = '#9e7324';
        ctx.font = '16px "Courier New", monospace';
        ctx.fillText(certSubtitle, 500, 122);

        // 4. Main Title
        ctx.fillStyle = '#221a0f';
        ctx.font = 'bold 44px "Microsoft JhengHei", "PingFang TC", sans-serif';
        ctx.shadowColor = 'rgba(0,0,0,0.15)';
        ctx.shadowBlur = 6;
        ctx.fillText(levelTitle, 500, 185);
        ctx.shadowBlur = 0;

        // Decorative horizontal gold line
        ctx.strokeStyle = badgeColor;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(250, 210);
        ctx.lineTo(750, 210);
        ctx.stroke();

        // 5. Player Name Award Banner
        ctx.fillStyle = '#555';
        ctx.font = '22px "Microsoft JhengHei", sans-serif';
        ctx.fillText('茲證明數學探險家', 500, 260);

        ctx.fillStyle = '#b83b14';
        ctx.font = 'bold 46px "Microsoft JhengHei", sans-serif';
        ctx.fillText(`【 ${playerName || '算術冒險者'} 】 同學`, 500, 320);

        // 6. Certificate Description & Achievement
        ctx.fillStyle = '#3a3328';
        ctx.font = '20px "Microsoft JhengHei", sans-serif';

        // Word wrap description nicely
        const descWords = certDesc;
        ctx.fillText(descWords.substring(0, 30), 500, 380);
        ctx.fillText(descWords.substring(30), 500, 415);

        // Stats Box
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        ctx.fillRect(260, 460, 480, 70);
        ctx.strokeStyle = badgeColor;
        ctx.lineWidth = 2;
        ctx.strokeRect(260, 460, 480, 70);

        ctx.fillStyle = '#2b2013';
        ctx.font = 'bold 22px "Microsoft JhengHei", sans-serif';
        ctx.fillText(`總累積積分：${score} 分    |    通關用時：${clearTimeStr || '02:30'}`, 500, 504);

        // 7. Golden Stamp / Seal on the Left
        const sealX = 180;
        const sealY = 575;
        ctx.save();
        ctx.beginPath();
        ctx.arc(sealX, sealY, 48, 0, Math.PI * 2);
        ctx.fillStyle = '#c72c1e';
        ctx.fill();
        ctx.strokeStyle = '#ffd700';
        ctx.lineWidth = 4;
        ctx.stroke();

        ctx.fillStyle = '#ffd700';
        ctx.font = 'bold 15px "Microsoft JhengHei", sans-serif';
        ctx.fillText('數學密室', sealX, sealY - 10);
        ctx.fillText('官方認證', sealX, sealY + 12);
        ctx.font = '11px sans-serif';
        ctx.fillText('VERIFIED', sealX, sealY + 28);
        ctx.restore();

        // 8. Signatures on the Right
        const sigX = 800;
        ctx.fillStyle = '#444';
        ctx.font = '16px "Microsoft JhengHei", sans-serif';
        ctx.fillText('密室考驗審定委員會：', sigX, 555);

        ctx.fillStyle = '#1c150c';
        ctx.font = 'italic bold 24px "Brush Script MT", cursive, serif';
        ctx.fillText('Grandmaster Euler', sigX, 590);

        ctx.fillStyle = '#666';
        ctx.font = '14px sans-serif';
        const todayStr = new Date().toLocaleDateString('zh-TW');
        ctx.fillText(`發證日期：${todayStr}`, sigX, 620);

        return canvas;
    }
}

window.leaderboardManager = new LeaderboardManager();
