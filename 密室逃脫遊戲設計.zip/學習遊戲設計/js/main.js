// main.js - Application Entry & UI Bindings

document.addEventListener('DOMContentLoaded', () => {
    // Quick name selection tags
    const quickTags = document.querySelectorAll('.quick-name-tag');
    const nameInput = document.getElementById('player-name-input');

    quickTags.forEach(tag => {
        tag.addEventListener('click', () => {
            nameInput.value = tag.innerText;
            window.soundEngine.playClick();
        });
    });

    // Pre-initialize 3D Escape Game in background for instant visual immersion
    try {
        window.escapeGame = new EscapeGame();
    } catch (e) {
        console.warn("Pre-init game error:", e);
    }

    const startBtn = document.getElementById('start-game-btn');

    // Support Enter key on name input
    nameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            startBtn.click();
        }
    });

    // Start Game Button
    startBtn.addEventListener('click', () => {
        let name = nameInput.value.trim();
        if (!name) name = '四年級算術小偵探';

        window.soundEngine.init();
        window.soundEngine.playClick();

        // Hide start modal
        const startModal = document.getElementById('start-modal');
        startModal.classList.remove('active');
        startModal.style.display = 'none';

        // Update HUD
        document.getElementById('hud-player-name').innerText = name;

        // Initialize or update 3D Escape Game
        if (!window.escapeGame) {
            window.escapeGame = new EscapeGame();
        }
        window.escapeGame.playerName = name;
        window.escapeGame.startTimer();

        // Welcome toast
        setTimeout(() => {
            window.escapeGame.showToast(`🎯 歡迎【${name}】！請按住滑鼠拖曳 360° 環顧密室，調查發光道具與密碼鎖！`, 'info');
        }, 600);
    });

    // Sound Mute Toggle
    const soundBtn = document.getElementById('sound-toggle-btn');
    soundBtn.addEventListener('click', () => {
        const isSoundOn = window.soundEngine.toggleMute();
        soundBtn.innerText = isSoundOn ? '🔊' : '🔇';
        if (isSoundOn) window.soundEngine.playClick();
    });

    // Leaderboard HUD Button
    const lbBtn = document.getElementById('leaderboard-btn');
    lbBtn.addEventListener('click', () => {
        window.soundEngine.playClick();
        const records = window.leaderboardManager.getScores();
        if (window.escapeGame) {
            window.escapeGame.renderLeaderboardModal(records);
        } else {
            // If before starting game
            const dummy = new EscapeGame();
            window.escapeGame = dummy;
            dummy.renderLeaderboardModal(records);
        }
    });

    // Close Leaderboard Button
    const closeLbBtn = document.getElementById('close-leaderboard-btn');
    closeLbBtn.addEventListener('click', () => {
        window.soundEngine.playClick();
        document.getElementById('leaderboard-modal').classList.remove('active');
    });

    // Replay / Play Again Button
    const replayBtn = document.getElementById('replay-game-btn');
    replayBtn.addEventListener('click', () => {
        window.soundEngine.playClick();
        document.getElementById('leaderboard-modal').classList.remove('active');

        if (window.escapeGame) {
            window.escapeGame.score = 0;
            window.escapeGame.inventory = [];
            window.escapeGame.updateInventoryUI();
            window.escapeGame.addScore(0);
            window.escapeGame.buildRoom1();
            window.escapeGame.updateRoomBadge();
            window.escapeGame.startTimer();
            window.escapeGame.showToast('🚀 密室題目與道具已全面動態刷新！重新啟動時空逃脫！', 'success');
        }
    });

    // Close Puzzle Button
    const closePuzzleBtn = document.getElementById('close-puzzle-btn');
    closePuzzleBtn.addEventListener('click', () => {
        window.soundEngine.playClick();
        document.getElementById('puzzle-modal').classList.remove('active');
    });

    // Keyboard Shortcuts (1: Room 1, 2: Room 2, 3: Room 3, P: Puzzle, L: Leaderboard)
    window.addEventListener('keydown', (e) => {
        if (e.target && e.target.tagName === 'INPUT') return;
        if (!window.escapeGame) return;

        if (e.key === '1') {
            window.escapeGame.buildRoom1();
            window.escapeGame.updateRoomBadge();
            window.escapeGame.showToast('已切換至【第一密室：歐式古典莊園】', 'info');
        } else if (e.key === '2') {
            window.escapeGame.buildRoom2();
            window.escapeGame.updateRoomBadge();
            window.escapeGame.showToast('已切換至【第二密室：未來科幻實驗室】', 'info');
        } else if (e.key === '3') {
            window.escapeGame.buildRoom3();
            window.escapeGame.updateRoomBadge();
            window.escapeGame.showToast('已切換至【第三密室：奇幻遠古神廟】', 'info');
        } else if (e.key === 'p' || e.key === 'P') {
            window.escapeGame.openDoorPuzzle();
        } else if (e.key === 'l' || e.key === 'L') {
            const records = window.leaderboardManager.getScores();
            window.escapeGame.renderLeaderboardModal(records);
        }
    });

    // URL parameter auto-actions for automated demos & testing
    const params = new URLSearchParams(window.location.search);
    if (params.get('start') === '1' || params.get('room') || params.get('puzzle') || params.get('cert') || params.get('lb')) {
        startBtn.click();
        const roomNum = parseInt(params.get('room'), 10);
        if (roomNum === 2) window.escapeGame.buildRoom2();
        else if (roomNum === 3) window.escapeGame.buildRoom3();

        if (params.get('puzzle') === '1') {
            window.escapeGame.openDoorPuzzle();
        } else if (params.get('cert') === '1') {
            window.escapeGame.showCertificateModal(roomNum || 1);
        } else if (params.get('lb') === '1') {
            const records = window.leaderboardManager.getScores();
            window.escapeGame.renderLeaderboardModal(records);
        }
    }
});
