using System;
using System.IO;
using System.Net;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace EscapeMathGame
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            int port = 54321;
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            HttpListener listener = null;

            // Try finding a working port
            for (int p = 54321; p < 54340; p++)
            {
                try
                {
                    listener = new HttpListener();
                    listener.Prefixes.Add("http://127.0.0.1:" + p + "/");
                    listener.Start();
                    port = p;
                    break;
                }
                catch
                {
                    if (listener != null)
                    {
                        try { listener.Close(); } catch { }
                    }
                }
            }

            if (listener == null || !listener.IsListening)
            {
                // Fallback: directly open file
                string localFile = Path.Combine(baseDir, "index.html");
                Process.Start(new ProcessStartInfo(localFile) { UseShellExecute = true });
                return;
            }

            // Start server thread
            Thread serverThread = new Thread(() =>
            {
                while (listener.IsListening)
                {
                    try
                    {
                        var context = listener.GetContext();
                        ThreadPool.QueueUserWorkItem((ctx) =>
                        {
                            var httpContext = (HttpListenerContext)ctx;
                            try
                            {
                                string urlPath = httpContext.Request.Url.AbsolutePath.TrimStart('/');
                                if (string.IsNullOrEmpty(urlPath)) urlPath = "index.html";

                                string filePath = Path.Combine(baseDir, urlPath.Replace('/', Path.DirectorySeparatorChar));
                                if (File.Exists(filePath))
                                {
                                    byte[] bytes = File.ReadAllBytes(filePath);
                                    string ext = Path.GetExtension(filePath).ToLower();
                                    string mime = "application/octet-stream";

                                    if (ext == ".html" || ext == ".htm") mime = "text/html; charset=utf-8";
                                    else if (ext == ".css") mime = "text/css; charset=utf-8";
                                    else if (ext == ".js") mime = "application/javascript; charset=utf-8";
                                    else if (ext == ".png") mime = "image/png";
                                    else if (ext == ".jpg" || ext == ".jpeg") mime = "image/jpeg";
                                    else if (ext == ".svg") mime = "image/svg+xml";

                                    httpContext.Response.ContentType = mime;
                                    httpContext.Response.ContentLength64 = bytes.Length;
                                    httpContext.Response.OutputStream.Write(bytes, 0, bytes.Length);
                                }
                                else
                                {
                                    httpContext.Response.StatusCode = 404;
                                }
                            }
                            catch { }
                            finally
                            {
                                try { httpContext.Response.OutputStream.Close(); } catch { }
                            }
                        }, context);
                    }
                    catch
                    {
                        break;
                    }
                }
            });
            serverThread.IsBackground = true;
            serverThread.Start();

            // Find browser
            string gameUrl = "http://127.0.0.1:" + port + "/index.html";
            string edge1 = @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe";
            string edge2 = @"C:\Program Files\Microsoft\Edge\Application\msedge.exe";
            string chrome1 = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
            string chrome2 = @"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe";

            string browserPath = null;
            if (File.Exists(edge1)) browserPath = edge1;
            else if (File.Exists(edge2)) browserPath = edge2;
            else if (File.Exists(chrome1)) browserPath = chrome1;
            else if (File.Exists(chrome2)) browserPath = chrome2;

            Process gameProc = null;
            if (browserPath != null)
            {
                string args = string.Format("--app=\"{0}\" --window-size=1280,760", gameUrl);
                gameProc = Process.Start(new ProcessStartInfo(browserPath, args) { UseShellExecute = false });
            }
            else
            {
                gameProc = Process.Start(new ProcessStartInfo(gameUrl) { UseShellExecute = true });
            }

            if (gameProc != null)
            {
                gameProc.WaitForExit();
            }
            else
            {
                Thread.Sleep(3000);
            }

            try
            {
                listener.Stop();
                listener.Close();
            }
            catch { }
        }
    }
}
